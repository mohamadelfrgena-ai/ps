var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// data/gametests/src/spawnGuide.ts
import { ItemStack, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
function rawLines(keys) {
  const rawtext = [];
  for (const k of keys) {
    if (rawtext.length > 0)
      rawtext.push({ text: "\n" });
    rawtext.push(k === "" ? { text: "" } : { translate: k });
  }
  return { rawtext };
}
var CARFORM, ABILITIES_KEYS, SpawnGuide, spawnGuide_default;
var init_spawnGuide = __esm({
  "data/gametests/src/spawnGuide.ts"() {
    "use strict";
    CARFORM = [
      { titleKey: "guide.car.big_suv", materialKey: "guide.material.iron_ingot", icon: "textures/bh/suca/items/big_suv" },
      { titleKey: "guide.car.suv", materialKey: "guide.material.coal", icon: "textures/bh/suca/items/suv" },
      { titleKey: "guide.car.crossover", materialKey: "guide.material.copper_ingot", icon: "textures/bh/suca/items/crossover" },
      { titleKey: "guide.car.truck", materialKey: "guide.material.gold_ingot", icon: "textures/bh/suca/items/truck" },
      { titleKey: "guide.car.sport_car", materialKey: "guide.material.diamond", icon: "textures/bh/suca/items/sport_car" },
      { titleKey: "guide.car.van", materialKey: "guide.material.resin_brick", icon: "textures/bh/suca/items/van" }
    ];
    ABILITIES_KEYS = [
      "guide.ability.intro",
      "",
      "guide.ability.regular",
      "",
      "guide.ability.bouncy",
      "",
      "guide.ability.fast_flat",
      "",
      "guide.ability.fast_sliding",
      "",
      "guide.ability.high_resistance",
      "",
      "guide.ability.light",
      "",
      "guide.ability.slow_flat",
      "",
      "guide.ability.slow_sliding",
      "",
      "guide.ability.sticky",
      "",
      "guide.ability.tnt"
    ];
    SpawnGuide = class {
      showGuide(player) {
        const form = new ActionFormData().title({ translate: "guide.title" }).body({ translate: "guide.body" });
        for (const car of CARFORM)
          form.button({ translate: car.titleKey }, car.icon);
        form.button({ translate: "guide.button.abilities" }, "textures/bh/suca/items/guide_book");
        form.button({ translate: "guide.button.sulfur" }, "textures/bh/suca/items/sulfur_dust");
        form.show(player).then((r) => {
          if (r.canceled || r.selection === void 0)
            return;
          if (r.selection < CARFORM.length)
            this.showCar(player, CARFORM[r.selection]);
          else if (r.selection === CARFORM.length)
            this.showAbilities(player);
          else
            this.showSulfurDust(player);
        });
      }
      showCar(player, car) {
        new ActionFormData().title({ translate: car.titleKey }).body({ translate: "guide.recipe.body", with: { rawtext: [{ translate: car.materialKey }] } }).button({ translate: "guide.button.back" }).show(player).then((r) => {
          if (!r.canceled)
            this.showGuide(player);
        });
      }
      showAbilities(player) {
        new ActionFormData().title({ translate: "guide.button.abilities" }).body(rawLines(ABILITIES_KEYS)).button({ translate: "guide.button.back" }).show(player).then((r) => {
          if (!r.canceled)
            this.showGuide(player);
        });
      }
      showSulfurDust(player) {
        new ActionFormData().title({ translate: "guide.button.sulfur" }).body({ translate: "guide.sulfur.body" }).button({ translate: "guide.button.back" }).show(player).then((r) => {
          if (!r.canceled)
            this.showGuide(player);
        });
      }
      firstSpawn(player) {
        if (player.getDynamicProperty("bh_suca:guide_book") === void 0)
          system.run(() => {
            player.setDynamicProperty("bh_suca:guide_book", true);
            player.addItem(new ItemStack("bh_suca:guide_book"));
          });
      }
    };
    spawnGuide_default = new SpawnGuide();
  }
});

// data/gametests/src/component.ts
import { EntityEquippableComponent, EquipmentSlot, system as system2, GameMode } from "@minecraft/server";
function initSpawnCarComponent() {
  system2.beforeEvents.startup.subscribe((e) => {
    e.itemComponentRegistry.registerCustomComponent("bh_suca:spawnCarComponent", spawnCarComponent);
    e.itemComponentRegistry.registerCustomComponent("bh_suca:spawnGuideComponent", spawnGuideComponent);
  });
}
var cooldownMS, spawnCarComponent, spawnGuideComponent;
var init_component = __esm({
  "data/gametests/src/component.ts"() {
    "use strict";
    init_spawnGuide();
    cooldownMS = /* @__PURE__ */ new Map();
    spawnCarComponent = {
      onUseOn(e) {
        const { itemStack, block } = e;
        if (!e.source || !itemStack || !block)
          return;
        const source = e.source;
        const id = source.id;
        const ms = cooldownMS.get(id);
        if (ms && ms > Date.now())
          return;
        cooldownMS.set(id, Date.now() + 30);
        const loc = block.location;
        system2.run(() => {
          if (!source.isValid)
            return;
          const equip = source.getComponent(EntityEquippableComponent.componentId);
          if (equip) {
            try {
              if (source.getGameMode() === GameMode.Survival)
                equip.setEquipment(EquipmentSlot.Mainhand, void 0);
              source.dimension.spawnEntity(itemStack.typeId.replace("_item", ""), loc);
              cooldownMS.delete(id);
            } catch {
            }
          }
        });
      }
    };
    spawnGuideComponent = {
      onUse(e) {
        const { itemStack, source } = e;
        if (!source || !itemStack)
          return;
        system2.run(() => {
          spawnGuide_default.showGuide(e.source);
        });
      }
    };
  }
});

// data/gametests/src/types.ts
function blockToType(blockId) {
  const id = blockId;
  if (id === "minecraft:tnt")
    return 9 /* TNT */;
  if (id === "minecraft:honeycomb_block" || id === "minecraft:honey_block")
    return 8 /* Sticky */;
  if (id === "minecraft:soul_sand" || id === "minecraft:soul_soil")
    return 4 /* HighResistance */;
  if (id.endsWith("wool"))
    return 5 /* Light */;
  if (id.includes("ice") || id === "minecraft:snow_block" || id === "minecraft:snow")
    return 3 /* FastSliding */;
  if (id.includes("mushroom") || id === "minecraft:mycelium" || id.includes("wart_block") || id === "minecraft:shroomlight")
    return 7 /* SlowSliding */;
  if (id.endsWith("_ore") || id.includes("copper") || id === "minecraft:ancient_debris" || METAL_BLOCKS.has(id))
    return 6 /* SlowFlat */;
  if (id.endsWith("_planks") || id.endsWith("_log") || id.endsWith("_wood") || id.includes("bamboo") || id.includes("resin"))
    return 1 /* Bouncy */;
  if (FAST_FLAT.has(id) || id.includes("coral_block") || id.includes("sponge") || id.includes("froglight"))
    return 2 /* FastFlat */;
  if (id.endsWith("concrete_powder") || REGULAR_BLOCKS.has(id))
    return 0 /* Regular */;
  return void 0;
}
function createCarState() {
  return {
    prevVelX: 0,
    prevVelY: 0,
    prevVelZ: 0,
    wasDrifting: false,
    fallStartY: void 0,
    hitCooldowns: /* @__PURE__ */ new Map(),
    tntProximity: /* @__PURE__ */ new Map()
  };
}
var CAR_TYPEIDS, REGULAR_BLOCKS, METAL_BLOCKS, FAST_FLAT, NON_TANGIBLE;
var init_types = __esm({
  "data/gametests/src/types.ts"() {
    "use strict";
    CAR_TYPEIDS = [
      "bh_suca:big_suv",
      "bh_suca:crossover",
      "bh_suca:sport_car",
      "bh_suca:truck",
      "bh_suca:suv",
      "bh_suca:van"
    ];
    REGULAR_BLOCKS = /* @__PURE__ */ new Set([
      "minecraft:mud",
      "minecraft:muddy_mangrove_roots",
      "minecraft:packed_mud",
      "minecraft:coal_block",
      "minecraft:dirt",
      "minecraft:coarse_dirt",
      "minecraft:rooted_dirt",
      "minecraft:podzol",
      "minecraft:grass_block",
      "minecraft:clay"
    ]);
    METAL_BLOCKS = /* @__PURE__ */ new Set([
      "minecraft:iron_block",
      "minecraft:gold_block",
      "minecraft:diamond_block",
      "minecraft:emerald_block",
      "minecraft:netherite_block",
      "minecraft:lapis_block",
      "minecraft:redstone_block",
      "minecraft:raw_iron_block",
      "minecraft:raw_gold_block",
      "minecraft:raw_copper_block"
    ]);
    FAST_FLAT = /* @__PURE__ */ new Set([
      "minecraft:moss_block",
      "minecraft:pale_moss_block",
      "minecraft:dried_kelp_block",
      "minecraft:pumpkin",
      "minecraft:carved_pumpkin",
      "minecraft:lit_pumpkin",
      "minecraft:melon_block",
      "minecraft:hay_block",
      "minecraft:slime",
      "minecraft:slime_block"
    ]);
    NON_TANGIBLE = /* @__PURE__ */ new Set([
      "minecraft:short_grass",
      "minecraft:tall_grass",
      "minecraft:fern",
      "minecraft:large_fern",
      "minecraft:deadbush",
      "minecraft:bush",
      "minecraft:firefly_bush",
      "minecraft:leaf_litter",
      "minecraft:pink_petals",
      "minecraft:wildflowers",
      "minecraft:dandelion",
      "minecraft:poppy",
      "minecraft:blue_orchid",
      "minecraft:allium",
      "minecraft:azure_bluet",
      "minecraft:red_tulip",
      "minecraft:orange_tulip",
      "minecraft:white_tulip",
      "minecraft:pink_tulip",
      "minecraft:oxeye_daisy",
      "minecraft:cornflower",
      "minecraft:lily_of_the_valley",
      "minecraft:wither_rose",
      "minecraft:sunflower",
      "minecraft:lilac",
      "minecraft:rose_bush",
      "minecraft:peony",
      "minecraft:torchflower",
      "minecraft:pitcher_plant",
      "minecraft:cactus_flower",
      "minecraft:open_eyeblossom",
      "minecraft:closed_eyeblossom",
      "minecraft:brown_mushroom",
      "minecraft:red_mushroom",
      "minecraft:oak_sapling",
      "minecraft:spruce_sapling",
      "minecraft:birch_sapling",
      "minecraft:jungle_sapling",
      "minecraft:acacia_sapling",
      "minecraft:dark_oak_sapling",
      "minecraft:cherry_sapling",
      "minecraft:pale_oak_sapling",
      "minecraft:mangrove_propagule",
      "minecraft:bamboo",
      "minecraft:bamboo_sapling",
      "minecraft:reeds",
      "minecraft:crimson_roots",
      "minecraft:warped_roots",
      "minecraft:nether_sprouts",
      "minecraft:hanging_roots",
      "minecraft:vine",
      "minecraft:weeping_vines",
      "minecraft:twisting_vines",
      "minecraft:cave_vines",
      "minecraft:cave_vines_body_with_berries",
      "minecraft:cave_vines_head_with_berries",
      "minecraft:glow_lichen",
      "minecraft:seagrass",
      "minecraft:kelp",
      "minecraft:waterlily",
      "minecraft:wheat",
      "minecraft:carrots",
      "minecraft:potatoes",
      "minecraft:beetroot",
      "minecraft:nether_wart",
      "minecraft:pumpkin_stem",
      "minecraft:melon_stem",
      "minecraft:torchflower_crop",
      "minecraft:pitcher_crop",
      "minecraft:sweet_berry_bush",
      "minecraft:fire",
      "minecraft:soul_fire",
      "minecraft:snow_layer",
      "minecraft:web",
      "minecraft:trip_wire",
      "minecraft:redstone_wire",
      "minecraft:rail",
      "minecraft:golden_rail",
      "minecraft:detector_rail",
      "minecraft:activator_rail",
      "minecraft:torch",
      "minecraft:soul_torch",
      "minecraft:redstone_torch",
      "minecraft:unlit_redstone_torch",
      "minecraft:underwater_torch",
      "minecraft:colored_torch_blue",
      "minecraft:colored_torch_green",
      "minecraft:colored_torch_purple",
      "minecraft:colored_torch_red",
      "minecraft:copper_torch",
      "minecraft:brain_coral_fan",
      "minecraft:bubble_coral_fan",
      "minecraft:fire_coral_fan",
      "minecraft:horn_coral_fan",
      "minecraft:tube_coral_fan",
      "minecraft:dead_brain_coral_fan",
      "minecraft:dead_bubble_coral_fan",
      "minecraft:dead_fire_coral_fan",
      "minecraft:dead_horn_coral_fan",
      "minecraft:dead_tube_coral_fan"
    ]);
  }
});

// data/gametests/src/utils.ts
function getRider(entity) {
  const rideable = entity.getComponent("minecraft:rideable");
  return rideable?.getRiders()[0];
}
function isPassenger(entity, target) {
  const rideable = entity.getComponent("minecraft:rideable");
  if (rideable) {
    const passengers = rideable.getRiders();
    if (passengers) {
      for (let i = 0; i < passengers.length; i++)
        if (passengers[i].id === target.id)
          return true;
    }
  }
  return false;
}
function waterMovement(car, rider, fluidSpeed) {
  const vel = car.getVelocity();
  const forward = rider.inputInfo.getMovementVector().y;
  const below = car.dimension.getBlock(car.location);
  if (below && below.typeId === "minecraft:water") {
    const dir = facingDirection(car);
    const maxSpeed = forward * fluidSpeed.max;
    car.applyImpulse({
      x: (dir.x * maxSpeed - vel.x) * fluidSpeed.accel,
      y: 0.01,
      z: (dir.z * maxSpeed - vel.z) * fluidSpeed.accel
    });
  }
}
function lavaMovement(car, rider, fluidSpeed) {
  const vel = car.getVelocity();
  const forward = rider.inputInfo.getMovementVector().y;
  const below = car.dimension.getBlock(car.location);
  if (below && below.typeId === "minecraft:lava") {
    const dir = facingDirection(car);
    const maxSpeed = forward * fluidSpeed.max;
    car.applyImpulse({
      x: (dir.x * maxSpeed - vel.x) * fluidSpeed.accel,
      y: 0.01,
      z: (dir.z * maxSpeed - vel.z) * fluidSpeed.accel
    });
  }
}
function getSpeed(entity) {
  const move = entity.getComponent("minecraft:movement");
  return move?.currentValue ?? 0;
}
function setSpeed(entity, value) {
  const move = entity.getComponent("minecraft:movement");
  move?.setCurrentValue(value);
}
function facingDirection(entity) {
  const yaw = entity.getRotation().y * Math.PI / 180;
  return { x: -Math.sin(yaw), y: 0, z: Math.cos(yaw) };
}
function scale(v, s) {
  return { x: v.x * s, y: v.y * s, z: v.z * s };
}
function subtract(a, b) {
  return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}
function horizontalLength(v) {
  return Math.sqrt(v.x * v.x + v.z * v.z);
}
function normalize(v) {
  const l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
  return l > 0 ? scale(v, 1 / l) : { x: 0, y: 0, z: 0 };
}
var init_utils = __esm({
  "data/gametests/src/utils.ts"() {
    "use strict";
  }
});

// data/gametests/src/carAbilities/bouncy.ts
import { system as system3 } from "@minecraft/server";
var Bouncy;
var init_bouncy = __esm({
  "data/gametests/src/carAbilities/bouncy.ts"() {
    "use strict";
    init_utils();
    Bouncy = class {
      constructor() {
        this.cooldown = 60;
        this.fluidSpeed = { base: 0.3, max: 2, accel: 0.05 };
      }
      ability(car) {
        car.playAnimation("bouncy");
        system3.runTimeout(() => {
          try {
            car.applyImpulse({ x: 0, y: 2.5, z: 0 });
          } catch {
          }
        }, 1);
      }
      passive(car, rider, state) {
        const vel = car.getVelocity();
        if (!car.isValid)
          return;
        if (!rider)
          return;
        waterMovement(car, rider, this.fluidSpeed);
        if (car.isOnGround) {
          if (state.fallStartY !== void 0) {
            const fallDistance = state.fallStartY - car.location.y;
            const power = Math.round(fallDistance / 20 * 100 / 100);
            if (power > 0.5)
              try {
                car.applyImpulse({ x: 0, y: power, z: 0 });
              } catch {
              }
            state.fallStartY = void 0;
          }
        } else {
          const y = car.location.y;
          if (state.fallStartY === void 0 || y > state.fallStartY)
            state.fallStartY = y;
        }
        if (Math.abs(state.prevVelX) > 0.3 && Math.abs(vel.x) < 0.1) {
          car.clearVelocity();
          car.applyImpulse({ x: -state.prevVelX * 3, y: 0, z: 0 });
        }
        if (Math.abs(state.prevVelZ) > 0.3 && Math.abs(vel.z) < 0.1) {
          car.applyImpulse({ x: 0, y: 0, z: -state.prevVelZ * 3 });
        }
      }
    };
  }
});

// data/gametests/src/carAbilities/fastFlat.ts
import { system as system4 } from "@minecraft/server";
var FastFlat;
var init_fastFlat = __esm({
  "data/gametests/src/carAbilities/fastFlat.ts"() {
    "use strict";
    init_utils();
    FastFlat = class {
      constructor() {
        this.cooldown = 40;
        this.speed = { base: 0.3, max: 1.5, accel: 0.03 };
      }
      ability(car) {
        if (!car.isValid)
          return;
        const dir = facingDirection(car);
        let time = 10;
        car.playAnimation("fast_flat");
        const temp = system4.runInterval(() => {
          if (!car.isValid) {
            system4.clearRun(temp);
            return;
          }
          time--;
          try {
            car.applyImpulse(scale(dir, 1.5));
          } catch {
          }
          if (time == 0)
            system4.clearRun(temp);
        });
      }
    };
  }
});

// data/gametests/src/carAbilities/fastSliding.ts
import { system as system5 } from "@minecraft/server";
var FastSliding;
var init_fastSliding = __esm({
  "data/gametests/src/carAbilities/fastSliding.ts"() {
    "use strict";
    init_utils();
    FastSliding = class {
      constructor() {
        this.cooldown = 40;
        this.speed = { base: 0.5, max: 1.3, accel: 0.05 };
      }
      ability(car) {
        if (!car.isValid)
          return;
        const dir = facingDirection(car);
        let time = 10;
        car.playAnimation("fast_sliding");
        const temp = system5.runInterval(() => {
          if (!car.isValid) {
            system5.clearRun(temp);
            return;
          }
          time--;
          car.applyImpulse(scale(dir, 1.5));
          if (time == 0)
            system5.clearRun(temp);
        });
      }
    };
  }
});

// data/gametests/src/carAbilities/highResistance.ts
import { EntityRideableComponent } from "@minecraft/server";
var HighResistance;
var init_highResistance = __esm({
  "data/gametests/src/carAbilities/highResistance.ts"() {
    "use strict";
    init_types();
    init_utils();
    HighResistance = class {
      constructor() {
        this.cooldown = 140;
      }
      ability(car) {
        if (!car.isValid)
          return;
        const mobs = car.dimension.getEntities({ location: car.location, maxDistance: 10, excludeTypes: CAR_TYPEIDS });
        car.playAnimation("high_resistance");
        for (const mob of mobs) {
          if (mob.isValid && !isPassenger(car, mob)) {
            const dir = normalize(subtract(mob.location, car.location));
            mob.applyKnockback({ x: dir.x, z: dir.z }, 2);
          }
        }
      }
      passive(car) {
        if (!car.isValid)
          return;
        this.passengerResistance(car);
        const loc = car.location;
        const fireballs = car.dimension.getEntities({ location: loc, maxDistance: 8, type: "minecraft:fireball" });
        for (const proj of fireballs) {
          if (!proj.isValid)
            continue;
          const vel = proj.getVelocity();
          const toCar = subtract(loc, proj.location);
          car.dimension.playSound("bh_suca.effect.high_resistance_passive", loc);
          if (vel.x * toCar.x + vel.y * toCar.y + vel.z * toCar.z > 0)
            proj.applyImpulse({ x: -2 * vel.x, y: -2 * vel.y, z: -2 * vel.z });
        }
      }
      passengerResistance(car) {
        const passengers = car.getComponent(EntityRideableComponent.componentId)?.getRiders();
        if (passengers) {
          passengers.forEach((p) => {
            try {
              p.addEffect("resistance", 40, { showParticles: false });
            } catch {
            }
          });
        }
      }
    };
  }
});

// data/gametests/src/carAbilities/light.ts
import { system as system6 } from "@minecraft/server";
var Light;
var init_light = __esm({
  "data/gametests/src/carAbilities/light.ts"() {
    "use strict";
    init_utils();
    Light = class {
      constructor() {
        this.cooldown = 60;
        this.fluidSpeed = { base: 0.3, max: 2, accel: 0.05 };
      }
      ability(car) {
        if (!car.isValid)
          return;
        const dir = facingDirection(car);
        const dirOff = { x: dir.x, y: dir.y + 0.03, z: dir.z };
        let time = 15;
        car.playAnimation("light");
        const temp = system6.runInterval(() => {
          if (!car.isValid) {
            system6.clearRun(temp);
            return;
          }
          time--;
          try {
            if (Math.random() > 0.3)
              car.applyImpulse(scale(dirOff, 1.3));
            else
              car.applyImpulse(scale(dir, 1.3));
          } catch {
          }
          if (time == 0)
            system6.clearRun(temp);
        });
      }
      passive(car, rider) {
        if (!car.isValid)
          return;
        const vel = car.getVelocity();
        if (vel.y < -0.25)
          try {
            car.applyImpulse({ x: 0, y: 0.2, z: 0 });
          } catch {
          }
        if (rider)
          waterMovement(car, rider, this.fluidSpeed);
      }
    };
  }
});

// data/gametests/src/carAbilities/regular.ts
var Regular;
var init_regular = __esm({
  "data/gametests/src/carAbilities/regular.ts"() {
    "use strict";
    init_utils();
    Regular = class {
      constructor() {
        this.speed = { base: 0.3, max: 1, accel: 0.03 };
        this.fluidSpeed = { base: 0.3, max: 2, accel: 0.05 };
      }
      passive(car, rider, state) {
        if (!car.isValid || !rider?.isValid)
          return;
        waterMovement(car, rider, this.fluidSpeed);
      }
    };
  }
});

// data/gametests/src/carAbilities/slowFlat.ts
import { EntityDamageCause, system as system7 } from "@minecraft/server";
var SlowFlat;
var init_slowFlat = __esm({
  "data/gametests/src/carAbilities/slowFlat.ts"() {
    "use strict";
    init_types();
    init_utils();
    SlowFlat = class {
      constructor() {
        this.cooldown = 60;
        this.speed = { base: 0.25, max: 0.25, accel: 0 };
      }
      ability(car) {
        if (!car.isValid)
          return;
        try {
          car.applyImpulse({ x: 0, y: -5, z: 0 });
          this.checkCannonBallDamage(car);
        } catch {
        }
      }
      passive(car) {
        const vel = car.getVelocity();
        this.checkCollisionDamage(car, vel);
      }
      checkCollisionDamage(car, vel) {
        if (horizontalLength(vel) < 0.2)
          return;
        const nearby = car.dimension.getEntities({ location: car.location, maxDistance: 2.5, excludeTypes: CAR_TYPEIDS });
        for (const mob of nearby) {
          if (!mob.isValid || isPassenger(car, mob))
            continue;
          const dir = normalize(subtract(mob.location, car.location));
          mob.applyDamage(4, { cause: EntityDamageCause.entityAttack, damagingEntity: car });
          mob.applyKnockback({ x: dir.x * 8, z: dir.z * 8 }, 0.5);
        }
      }
      checkCannonBallDamage(car) {
        let timeTimer = 200;
        const timer = system7.runInterval(() => {
          timeTimer--;
          const loc = car.location;
          try {
            const block = car.dimension.getBlock(loc)?.below();
            if (car.isValid && !block?.isAir && !block?.isLiquid) {
              system7.clearRun(timer);
              system7.runTimeout(() => {
                if (car.isValid)
                  car.dimension.playSound("bh_suca.effect.tnt", car.location);
              }, 5);
              car.playAnimation("slow_flat");
              const nearby = car.dimension.getEntities({ location: loc, maxDistance: 10, excludeTypes: CAR_TYPEIDS });
              for (const e of nearby) {
                if (e.isValid && !isPassenger(car, e)) {
                  const dir = normalize(subtract(e.location, loc));
                  try {
                    e.applyDamage(4, { cause: EntityDamageCause.entityAttack, damagingEntity: car });
                    e.applyKnockback({ x: dir.x, z: dir.z }, 0.6);
                  } catch {
                  }
                }
              }
            }
          } catch {
          }
          if (timeTimer === 0)
            system7.clearRun(timer);
        }, 1);
      }
    };
  }
});

// data/gametests/src/carAbilities/slowSliding.ts
import { system as system8 } from "@minecraft/server";
var SlowSliding;
var init_slowSliding = __esm({
  "data/gametests/src/carAbilities/slowSliding.ts"() {
    "use strict";
    init_types();
    init_utils();
    SlowSliding = class {
      constructor() {
        this.cooldown = 140;
        this.speed = { base: 0.3, max: 0.3, accel: 0 };
      }
      ability(car) {
        if (!car.isValid)
          return;
        let tick = 0;
        car.playAnimation("slow_sliding");
        const id = system8.runInterval(() => {
          if (tick >= 80 || !car.isValid) {
            system8.clearRun(id);
            return;
          }
          const yaw = tick * -18;
          car.setRotation({ x: car.getRotation().x, y: yaw });
          if (tick % 10 === 0) {
            const nearby = car.dimension.getEntities({ location: car.location, maxDistance: 10, excludeTypes: CAR_TYPEIDS });
            for (const mob of nearby) {
              if (!mob.isValid || isPassenger(car, mob))
                continue;
              const dir = normalize(subtract(mob.location, car.location));
              try {
                mob.applyKnockback({ x: dir.x, z: dir.z }, 0.6);
              } catch {
              }
            }
          }
          tick++;
        }, 1);
      }
      passive(car, rider, state) {
        if (!car.isValid)
          return;
        const vel = car.getVelocity();
        const speed = horizontalLength(vel);
        const dir = facingDirection(car);
        const sidewaysSpeed = Math.abs(vel.x * dir.z - vel.z * dir.x);
        const isDrifting = sidewaysSpeed > 0.25 && speed > 0.2;
        if (state.wasDrifting && !isDrifting && speed > 0.05) {
          const dir2 = normalize({ x: vel.x, y: 0, z: vel.z });
          car.applyImpulse(scale(dir2, 1.4));
        }
        state.wasDrifting = isDrifting;
      }
    };
  }
});

// data/gametests/src/carAbilities/sticky.ts
var Sticky;
var init_sticky = __esm({
  "data/gametests/src/carAbilities/sticky.ts"() {
    "use strict";
    init_types();
    Sticky = class {
      constructor() {
        this.cooldown = 140;
      }
      ability(car, rider) {
        if (!car.isValid)
          return;
        car.playAnimation("sticky");
        const items = car.dimension.getEntities({ location: car.location, maxDistance: 20, type: "minecraft:item" });
        for (const item of items) {
          if (item.isValid)
            item.teleport(rider.location);
        }
      }
      passive(car, rider, state) {
        if (!car.isValid)
          return;
        if (!this.nearWall(car.dimension, car.location))
          return;
        const vel = car.getVelocity();
        if (rider && rider.inputInfo.getMovementVector().y > 0)
          car.applyImpulse({ x: 0, y: -vel.y + rider.inputInfo.getMovementVector().y * 0.3, z: 0 });
        else
          car.applyImpulse({ x: -vel.x, y: -vel.y + 0.1172, z: -vel.z });
      }
      nearWall(dim, loc) {
        const x = Math.floor(loc.x), y = Math.floor(loc.y), z = Math.floor(loc.z);
        const boxSize = 2;
        const sides = [
          { x: x + boxSize, y, z },
          { x: x - boxSize, y, z },
          { x, y, z: z + boxSize },
          { x, y, z: z - boxSize }
        ];
        for (const p of sides) {
          const b = dim.getBlock(p);
          if (b && !b.isAir && !b.isLiquid && !NON_TANGIBLE.has(b.typeId))
            return true;
        }
        return false;
      }
    };
  }
});

// data/gametests/src/carAbilities/tnt.ts
import { system as system9 } from "@minecraft/server";
var TNT;
var init_tnt = __esm({
  "data/gametests/src/carAbilities/tnt.ts"() {
    "use strict";
    init_types();
    init_utils();
    TNT = class {
      constructor() {
        this.cooldown = 140;
        this.fluidSpeed = { base: 0.3, max: 2, accel: 0.05 };
      }
      ability(car) {
        if (!car.isValid)
          return;
        const loc = car.location;
        const nearby = car.dimension.getEntities({ location: loc, maxDistance: 15, excludeTypes: CAR_TYPEIDS });
        try {
          car.dimension.createExplosion(loc, 7.5, { breaksBlocks: false, causesFire: false, source: car });
          car.playAnimation("tnt");
          for (const e of nearby)
            if (e.isValid && !isPassenger(car, e)) {
              const dir = normalize(subtract(e.location, loc));
              e.applyKnockback({ x: dir.x * 2, z: dir.z * 2 }, 1.2);
            }
        } catch {
        }
      }
      passive(car, rider, state) {
        if (!car.isValid)
          return;
        if (horizontalLength(car.getVelocity()) < 0.2)
          return;
        if (rider) {
          waterMovement(car, rider, this.fluidSpeed);
          lavaMovement(car, rider, this.fluidSpeed);
        }
        const proximity = state.tntProximity;
        const now = system9.currentTick;
        const nearby = car.dimension.getEntities({ location: car.location, maxDistance: 2, excludeTypes: CAR_TYPEIDS });
        for (const mob of nearby) {
          if (!mob.isValid || isPassenger(car, mob))
            continue;
          if (proximity.has(mob.id)) {
            try {
              car.dimension.createExplosion(mob.location, 2, { breaksBlocks: false, causesFire: false, source: car });
              proximity.delete(mob.id);
            } catch {
            }
          } else {
            const dir = normalize(subtract(mob.location, car.location));
            try {
              mob.applyKnockback({ x: dir.x * 8, z: dir.z * 8 }, 0.5);
            } catch {
            }
            proximity.set(mob.id, { lastTouch: now });
          }
        }
        for (const [id, hit] of proximity)
          if (now - hit.lastTouch > 60)
            proximity.delete(id);
      }
    };
  }
});

// data/gametests/src/carAbilities/carAbilities.ts
var abilityMap;
var init_carAbilities = __esm({
  "data/gametests/src/carAbilities/carAbilities.ts"() {
    "use strict";
    init_types();
    init_bouncy();
    init_fastFlat();
    init_fastSliding();
    init_highResistance();
    init_light();
    init_regular();
    init_slowFlat();
    init_slowSliding();
    init_sticky();
    init_tnt();
    abilityMap = {
      [0 /* Regular */]: new Regular(),
      [1 /* Bouncy */]: new Bouncy(),
      [2 /* FastFlat */]: new FastFlat(),
      [3 /* FastSliding */]: new FastSliding(),
      [4 /* HighResistance */]: new HighResistance(),
      [5 /* Light */]: new Light(),
      [6 /* SlowFlat */]: new SlowFlat(),
      [7 /* SlowSliding */]: new SlowSliding(),
      [8 /* Sticky */]: new Sticky(),
      [9 /* TNT */]: new TNT()
    };
  }
});

// data/gametests/src/carManager.ts
import { ButtonState, EntityDamageCause as EntityDamageCause3, EntityHealthComponent, EntityRidingComponent as EntityRidingComponent2, EquipmentSlot as EquipmentSlot2, InputButton, InputPermissionCategory, ItemStack as ItemStack2, system as system10, world as world3 } from "@minecraft/server";
var TYPE_EVENT, FUEL_DYNPROP, MAX_FUEL, FUEL_VALUES, CarManager, carManager_default;
var init_carManager = __esm({
  "data/gametests/src/carManager.ts"() {
    "use strict";
    init_types();
    init_utils();
    init_carAbilities();
    TYPE_EVENT = {
      [4 /* HighResistance */]: "bh_suca:enable_high_resistance"
    };
    FUEL_DYNPROP = "bh_suca:fuel";
    MAX_FUEL = 4e3;
    FUEL_VALUES = {
      "minecraft:charcoal": 100,
      "minecraft:coal": 250,
      "minecraft:lava_bucket": 365,
      "bh_suca:sulfur_dust": 700
    };
    CarManager = class {
      constructor() {
        this.carStates = /* @__PURE__ */ new Map();
        this.jumpHeld = /* @__PURE__ */ new Set();
        this.cooldowns = /* @__PURE__ */ new Map();
      }
      carType(entity) {
        return entity.getProperty("bh_suca:car_type");
      }
      setType(car, type) {
        car.setProperty("bh_suca:car_type", type);
        car.triggerEvent("bh_suca:clear_groups");
        const event = TYPE_EVENT[type];
        if (event)
          car.triggerEvent(event);
      }
      handleDespawn(e) {
        if (!e.hurtEntity)
          return;
        const healthComp = e.hurtEntity.getComponent(EntityHealthComponent.componentId);
        if (healthComp && e.damage >= healthComp.currentValue) {
          e.cancel = true;
          const loc = e.hurtEntity.location;
          const dim = e.hurtEntity.dimension;
          const item = new ItemStack2(`${e.hurtEntity.typeId}_item`);
          const storedBlock = e.hurtEntity.getDynamicProperty("bh_suca:stored_block");
          const id = e.hurtEntity.getDynamicProperty("bh_suca:rider_id");
          this.handleRemove(e.hurtEntity.id);
          if (id) {
            const rider = world3.getEntity(id);
            system10.run(() => {
              if (rider?.isValid)
                this.setInputs(rider, true);
            });
          }
          system10.run(() => {
            try {
              e.hurtEntity.remove();
              dim.spawnItem(item, loc);
              if (storedBlock !== void 0)
                dim.spawnItem(new ItemStack2(storedBlock), loc);
            } catch {
            }
          });
        }
      }
      handleEvent(e) {
        switch (e.eventId) {
          case "bh_suca:tick": {
            this.tick(e.entity);
            break;
          }
          case "bh_suca:ride_start": {
            const rider = getRider(e.entity);
            if (rider) {
              e.entity.setDynamicProperty("bh_suca:rider_id", rider.id);
              this.setInputs(rider, false);
            }
            break;
          }
          case "bh_suca:ride_end": {
            const id = e.entity.getDynamicProperty("bh_suca:rider_id");
            if (id) {
              const rider = world3.getEntity(id);
              if (rider?.isValid)
                this.setInputs(rider, true);
            }
            e.entity.setDynamicProperty("bh_suca:rider_id", void 0);
            this.jumpHeld.delete(e.entity.id);
            const speed = abilityMap[this.carType(e.entity)]?.speed;
            if (speed)
              setSpeed(e.entity, speed.base);
            break;
          }
        }
      }
      setInputs(player, enabled) {
        player.inputPermissions.setPermissionCategory(InputPermissionCategory.Jump, enabled);
        player.inputPermissions.setPermissionCategory(InputPermissionCategory.MoveLeft, enabled);
        player.inputPermissions.setPermissionCategory(InputPermissionCategory.MoveRight, enabled);
      }
      tick(car) {
        if (!car.isValid)
          return;
        try {
          const rider = getRider(car);
          const type = this.carType(car);
          const state = this.getState(car);
          if (rider) {
            const hasFuel = this.handleFuel(car);
            if (hasFuel) {
              this.handleJump(car, rider, type);
              this.handleSpeed(car, type);
            } else
              setSpeed(car, 0);
            this.prevVelocity(car, state);
            this.showStatus(car, rider, type);
          }
          abilityMap[type]?.passive?.(car, rider, state);
        } catch {
        }
      }
      handleFuel(car) {
        let fuel = car.getDynamicProperty(FUEL_DYNPROP);
        if (fuel === void 0 || fuel === 0)
          return false;
        if (fuel > 0 && horizontalLength(car.getVelocity()) > 0.1) {
          fuel--;
          car.setDynamicProperty(FUEL_DYNPROP, fuel);
        }
        return true;
      }
      handleSpeed(car, type) {
        const speed = abilityMap[type]?.speed;
        if (!speed)
          return;
        if (horizontalLength(car.getVelocity()) > 0.1)
          setSpeed(car, Math.min(getSpeed(car) + speed.accel, speed.max));
        else
          setSpeed(car, speed.base);
      }
      handleRemove(id) {
        this.carStates.delete(id);
        this.jumpHeld.delete(id);
        this.cooldowns.delete(id);
      }
      handleJump(car, rider, type) {
        if (!rider) {
          this.jumpHeld.delete(car.id);
          return;
        }
        if (rider.inputInfo.getButtonState(InputButton.Jump) === ButtonState.Pressed) {
          const ability = abilityMap[type];
          const wasHeld = this.jumpHeld.has(car.id);
          if (ability.ability === void 0)
            return;
          if (!wasHeld) {
            if (!this.hasCooldown(car)) {
              ability.ability(car, rider);
              if (ability.cooldown)
                this.cooldowns.set(car.id, system10.currentTick + ability.cooldown);
            }
          }
          this.jumpHeld.add(car.id);
        } else
          this.jumpHeld.delete(car.id);
      }
      handleDamage(e) {
        if (!e.hurtEntity)
          return;
        if (e.damageSource.cause === EntityDamageCause3.entityExplosion) {
          const riding = e.hurtEntity.getComponent(EntityRidingComponent2.componentId);
          if (riding && CAR_TYPEIDS.includes(riding.entityRidingOn.typeId))
            e.cancel = true;
        }
      }
      handleInteraction(e) {
        const { player, target, itemStack } = e;
        if (!player || !target)
          return;
        if (itemStack) {
          const fuelValue = FUEL_VALUES[itemStack.typeId];
          if (fuelValue !== void 0) {
            e.cancel = true;
            const loc = target.location;
            system10.run(() => {
              if (!target.isValid)
                return;
              const fuel = target.getDynamicProperty(FUEL_DYNPROP) ?? 0;
              if (fuel >= MAX_FUEL)
                return;
              target.setDynamicProperty(FUEL_DYNPROP, Math.min(fuel + fuelValue, MAX_FUEL));
              if (itemStack.typeId === "minecraft:lava_bucket")
                this.replaceItem(player, new ItemStack2("minecraft:bucket"));
              else
                this.removeItem(player);
              target.dimension.playSound("bh_suca.insert_block", loc);
            });
          } else if (blockToType(itemStack.typeId) !== void 0) {
            e.cancel = true;
            system10.run(() => {
              if (this.storeBlock(target, itemStack))
                this.removeItem(player);
            });
          } else if (itemStack.typeId === "minecraft:shears") {
            const storedBlock = target.getDynamicProperty("bh_suca:stored_block");
            const loc = target.location;
            e.cancel = true;
            system10.run(() => {
              if (!target)
                return;
              if (storedBlock)
                target.dimension.spawnItem(new ItemStack2(storedBlock, 1), loc);
              try {
                target.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 air`);
                target.setDynamicProperty("bh_suca:stored_block", void 0);
              } catch {
              }
              this.setType(target, 0 /* Regular */);
              target.dimension.playSound("bh_suca.insert_block", loc);
            });
          } else {
            let canEnter = target.getProperty("bh_suca:can_enter");
            if (canEnter === false) {
              e.cancel = true;
              system10.run(() => {
                if (target.isValid)
                  target.setProperty("bh_suca:can_enter", true);
              });
              system10.runTimeout(() => {
                if (target.isValid)
                  target.setProperty("bh_suca:can_enter", false);
              }, 40);
            } else
              return;
          }
        } else {
          let canEnter = target.getProperty("bh_suca:can_enter");
          if (canEnter === false) {
            e.cancel = true;
            system10.run(() => {
              if (target.isValid)
                target.setProperty("bh_suca:can_enter", true);
            });
            system10.runTimeout(() => {
              if (target.isValid)
                target.setProperty("bh_suca:can_enter", false);
            }, 40);
          } else
            return;
        }
      }
      removeItem(player) {
        const equip = player.getComponent("minecraft:equippable");
        const slot = equip?.getEquipmentSlot(EquipmentSlot2.Mainhand);
        const item = slot?.getItem();
        if (!slot || !item)
          return;
        if (item.amount > 1) {
          item.amount--;
          slot.setItem(item);
        } else
          slot.setItem(void 0);
      }
      replaceItem(player, replacement) {
        const equip = player.getComponent("minecraft:equippable");
        const slot = equip?.getEquipmentSlot(EquipmentSlot2.Mainhand);
        if (!slot || !slot.getItem())
          return;
        slot.setItem(replacement);
      }
      storeBlock(car, item) {
        const type = blockToType(item.typeId);
        if (type === void 0)
          return false;
        const storedBlock = car.getDynamicProperty("bh_suca:stored_block");
        const loc = car.location;
        if (storedBlock && storedBlock === item.typeId)
          return false;
        if (storedBlock)
          car.dimension.spawnItem(new ItemStack2(storedBlock, 1), loc);
        try {
          car.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 ${item.typeId}`);
          car.setDynamicProperty("bh_suca:stored_block", item.typeId);
        } catch {
        }
        this.setType(car, type);
        car.dimension.playSound("bh_suca.insert_block", loc);
        return true;
      }
      showStatus(car, rider, type) {
        const ability = abilityMap[type];
        const end = this.cooldowns.get(car.id);
        if (ability?.ability && ability.cooldown && end !== void 0) {
          const remaining = end - system10.currentTick;
          if (remaining > 0) {
            try {
              rider.onScreenDisplay.setActionBar(`\xA77Cooldown \xA7f${(remaining / 20).toFixed(1)}s`);
            } catch {
            }
          } else {
            try {
              rider.onScreenDisplay.setActionBar("\xA7aAbility Ready!");
            } catch {
            }
            this.cooldowns.delete(car.id);
          }
          return;
        } else {
          const fuel = car.getDynamicProperty(FUEL_DYNPROP);
          try {
            if (fuel !== void 0 && fuel !== 0)
              rider.onScreenDisplay.setActionBar(`\xA7e\xA7f-= Fuel: ${(fuel / 40).toFixed()} / 100 =-`);
            else
              rider.onScreenDisplay.setActionBar("\xA7cOut of Fuel!");
          } catch {
          }
        }
      }
      hasCooldown(car) {
        const cooldown = this.cooldowns.get(car.id);
        if (cooldown && cooldown >= system10.currentTick)
          return true;
        return false;
      }
      getState(car) {
        let s = this.carStates.get(car.id);
        if (!s) {
          s = createCarState();
          this.carStates.set(car.id, s);
        }
        return s;
      }
      prevVelocity(car, state) {
        const vel = car.getVelocity();
        state.prevVelX = vel.x;
        state.prevVelY = vel.y;
        state.prevVelZ = vel.z;
      }
    };
    carManager_default = new CarManager();
  }
});

// data/gametests/src/sulfurDust.ts
import { EntityVariantComponent, ItemStack as ItemStack3 } from "@minecraft/server";
function handleSulfurCube(e) {
  const loc = e.deadEntity.location;
  const dim = e.deadEntity.dimension;
  const variant = e.deadEntity.getComponent(EntityVariantComponent.componentId);
  if (variant && variant.value === 2)
    try {
      dim.spawnItem(new ItemStack3("bh_suca:sulfur_dust"), loc);
    } catch {
    }
}
var init_sulfurDust = __esm({
  "data/gametests/src/sulfurDust.ts"() {
    "use strict";
  }
});

// data/gametests/src/events.ts
import { world as world4 } from "@minecraft/server";
var require_events = __commonJS({
  "data/gametests/src/events.ts"() {
    "use strict";
    init_carManager();
    init_types();
    init_spawnGuide();
    init_sulfurDust();
    world4.afterEvents.dataDrivenEntityTrigger.subscribe((e) => {
      if (e.eventId.startsWith("bh_suca:"))
        carManager_default.handleEvent(e);
    });
    world4.afterEvents.entityRemove.subscribe((e) => {
      if (CAR_TYPEIDS.includes(e.typeId))
        carManager_default.handleRemove(e.removedEntityId);
    });
    world4.beforeEvents.playerInteractWithEntity.subscribe((e) => {
      if (CAR_TYPEIDS.includes(e.target.typeId))
        carManager_default.handleInteraction(e);
    });
    world4.beforeEvents.entityHurt.subscribe((e) => {
      if (CAR_TYPEIDS.includes(e.hurtEntity.typeId))
        carManager_default.handleDespawn(e);
      else if (e.hurtEntity.typeId === "minecraft:player")
        carManager_default.handleDamage(e);
    });
    world4.afterEvents.playerSpawn.subscribe((e) => {
      if (e.initialSpawn === true)
        spawnGuide_default.firstSpawn(e.player);
    });
    world4.afterEvents.entityDie.subscribe((e) => {
      if (e.deadEntity.typeId === "minecraft:sulfur_cube")
        handleSulfurCube(e);
    });
  }
});

// data/gametests/src/main.ts
var require_main = __commonJS({
  "data/gametests/src/main.ts"() {
    init_component();
    var import_events = __toESM(require_events());
    initSpawnCarComponent();
  }
});
export default require_main();
