-- ============================================================================
--  AddonStation Mobile — تعيين الأدمن (جاهز للنسخ واللصق)
--  البريد: silverfoxinteractive@gmail.com
--  ⚠️ نفّذ هذا الملف فقط بعد:
--     1) تنفيذ 00_ALL_IN_ONE.sql
--     2) إنشاء الحساب من لوحة Supabase بنفس هذا البريد (Authentication → Users → Add user)
--  إن نفّذته قبل إنشاء الحساب ستظهر: "لا يوجد مستخدم بهذا البريد" — والملف آمن للتكرار.
-- ============================================================================

do $$
declare
  v_email text := 'silverfoxinteractive@gmail.com';   -- ✅ بريدك
  v_uid   uuid;
begin
  select id into v_uid from auth.users where email = v_email;
  if v_uid is null then
    raise notice 'لا يوجد مستخدم بهذا البريد: % — أنشئ الحساب أولاً', v_email;
    return;
  end if;

  insert into public.profiles (id, username, display_name)
  values (v_uid,
          coalesce(nullif(split_part(v_email,'@',1),''), 'player_' || substr(v_uid::text,1,8)),
          split_part(v_email,'@',1))
  on conflict (id) do nothing;

  insert into public.ac_wallets (user_id) values (v_uid) on conflict (user_id) do nothing;
  update public.profiles set role = 'admin' where id = v_uid;
  insert into public.admin_audit_log(actor_id, action, target_type, target_id, details)
  values (v_uid, 'admin_bootstrapped', 'profile', v_uid::text, jsonb_build_object('email', v_email));
  raise notice 'تم تعيين % مديراً (Admin) ✅', v_email;
end $$;

-- (اختياري) خطة أسطورية لك سنة كاملة لتجربة المحتوى المدفوع فوراً
update public.profiles
   set plan = 'legendary', plan_expires_at = now() + interval '365 days'
 where role = 'admin';

-- (اختياري) تفعيل تحويل بنكي للتجربة — كل الطرق معطّلة افتراضياً
update public.payment_method_settings
   set enabled = true,
       account_name = 'AddonStation',
       account_identifier = '091-0000000',
       instructions = 'حوّل المبلغ ثم ارفع صورة الإيصال ورقم العملية.'
 where code = 'bank_transfer';

-- ✅ تحقّق: الصق هذا وحده واضغط RUN
select p.id, p.username, p.display_name, p.role, p.plan, p.plan_expires_at, w.balance_ac
  from public.profiles p
  left join public.ac_wallets w on w.user_id = p.id
 where p.role = 'admin';
-- المتوقّع: صف واحد: role = admin · plan = legendary · balance_ac = 50
