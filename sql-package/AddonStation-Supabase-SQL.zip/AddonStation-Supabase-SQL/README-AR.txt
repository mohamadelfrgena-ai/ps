﻿AddonStation Mobile — حزمة SQL الجاهزة لمشروع Supabase
تاريخ التجهيز: 2026-09-29
=================================================================

الخطوة 1) نفّذ الملف الجامع (5 دقائق)
-----------------------------------------------------------------
1. في Supabase: SQL Editor → New query
2. افتح 00_ALL_IN_ONE.sql (زر يمين → Open with → Notepad)
3. Ctrl+A ثم Ctrl+C  ثم الصقه في المحرر كاملاً → RUN
4. المتوقّع:  Success. No rows returned

❌ إن ظهر خطأ أحمر: توقّف وأرسل نص الخطأ حرفياً مع رقم السطر.
   البديل: نفّذ الملفات المنفصلة بهذا الترتيب:
   01_schema → 02_functions_core → 03_functions_chat → 04_rls
   → 05_storage → 06_seed → 07_seed_assets → 10_realtime

الخطوة 2) تحقّق (الصق هذا الاستعلام وحده)
-----------------------------------------------------------------
select
  (select count(*) from information_schema.tables where table_schema='public') as tables,    -- 33
  (select count(*) from storage.buckets)                                       as buckets,   -- 6
  (select count(*) from pg_policies where schemaname in ('public','storage'))  as policies,  -- 76
  (select count(*) from public.subscription_plans)                             as plans,     -- 3
  (select count(*) from public.chat_channels)                                  as rooms,     -- 13
  (select count(*) from public.ac_tasks)                                       as tasks,     -- 6
  (select count(*) from public.sticker_packs)                                  as packs,     -- 5
  (select count(*) from public.site_assets)                                    as assets;    -- 286

الخطوة 3) أنشئ حساب الأدمن
-----------------------------------------------------------------
من لوحة Supabase: Authentication → Users → Add user → Create new user
     Email:    silverfoxinteractive@gmail.com
     Password: (كلمة قوية)
     ✅ Auto Confirm User

الخطوة 4) اجعله مديراً
-----------------------------------------------------------------
افتح 08_admin_bootstrap_READY.sql → Ctrl+A → Ctrl+C → الصقه في SQL Editor → RUN
المتوقّع: تم تعيين silverfoxinteractive@gmail.com مديراً (Admin) ✅

الخطوة 5) (اختياري) بوابات الدفع — نفّذ 09_gateway_functions.sql لاحقاً.

أخطاء شائعة
-----------------------------------------------------------------
| already exists        | أعدت التنفيذ            | طبيعي وآمن — تجاوزه                 |
| syntax error near $$  | اللصق ناقص              | انسخ 00_ALL_IN_ONE.sql كاملاً        |
| لا يوجد مستخدم بهذا البريد | الحساب لم يُنشأ    | نفّذ الخطوة 3 ثم أعد المحاولة        |
