﻿AddonStation Mobile — حزمة SQL الجاهزة لمشروع Supabase
تاريخ التجهيز: 2026-10-01
=================================================================

الخطوة 1) نفّذ الملف الجامع (5 دقائق)
-----------------------------------------------------------------
1. في Supabase: SQL Editor → New query
2. افتح 00_ALL_IN_ONE.sql (زر يمين → Open with → Notepad)
3. Ctrl+A ثم Ctrl+C  ثم الصقه في المحرر كاملاً → RUN
4. المتوقّع:  Success. No rows returned

❌ إن ظهر خطأ أحمر: توقّف وأرسل نص الخطأ حرفياً مع رقم السطر.
   البديل: نفّذ الملفات المنفصلة بهذا الترتيب:
   01_schema → 02_functions_core → 03_functions_chat → 04_rls
   → 05_storage → 06_seed → 07_seed_assets → 12_avatars
   → 10_realtime → 11_grants → 13_channels_icons → 14_redeem_codes
   → 15_assets_v2 → 16_language_room_names → 17_message_delete_window
   → 18_media_admin_only → 19_admin_panel_guard

الخطوة 2) تحقّق (الصق هذا الاستعلام وحده)
-----------------------------------------------------------------
select
  (select count(*) from information_schema.tables where table_schema='public') as tables,    -- 35
  (select count(*) from storage.buckets)                                       as buckets,   -- 6
  (select count(*) from pg_policies where schemaname in ('public','storage'))  as policies,  -- 78
  (select count(*) from public.subscription_plans)                             as plans,     -- 3
  (select count(*) from public.chat_channels)                                  as rooms,     -- 13
  (select count(*) from public.ac_tasks)                                       as tasks,     -- 6
  (select count(*) from public.sticker_packs)                                  as packs,     -- 5
  (select count(*) from public.site_assets)                                    as assets;    -- 311

الخطوة 3) أنشئ حساب الأدمن
-----------------------------------------------------------------
من لوحة Supabase: Authentication → Users → Add user → Create new user
     Email:    you@example.com
     Password: (كلمة قوية)
     ✅ Auto Confirm User

الخطوة 4) اجعله مديراً
-----------------------------------------------------------------
افتح 08_admin_bootstrap_READY.sql → Ctrl+A → Ctrl+C → الصقه في SQL Editor → RUN
المتوقّع: تم تعيين you@example.com مديراً (Admin) ✅

الخطوة 5) (اختياري) أكواد هدايا AC — مضمَّنة في 14_redeem_codes.sql :
   ولّد الأكواد من: لوحة الإدارة → AC Management → «أكواد هدايا AC» → توليد الأكواد
   أو من الحاسوب: python3 tools/make_redeem_codes.py -n 5

الخطوة 6) (اختياري) بوابات الدفع — نفّذ 09_gateway_functions.sql لاحقاً.

مشمول تلقائياً في 00_ALL_IN_ONE.sql (لا خطوة إضافية)
-----------------------------------------------------------------
• حذف الرسالة في الشات: خلال ٣ دقائق فقط بعد الإرسال، وبعدها لا يستطيع المستخدم
  حذفها (17_message_delete_window.sql) — والإدارة تُخفي/تحذف بلا حدّ زمني.
• أسماء غرف اللغة بلغتها: العربية · English · Español · Français · Português ·
  Русский · Türkçe · 中文 (16_language_room_names.sql).
• الأصول الجديدة: 492 أصلاً في 21 قسماً بدل القديمة (15_assets_v2.sql).
• الوسائط للأدمن فقط: مقاطع الفيديو والملفات الصوتية والتسجيلات الصوتية لا يرسلها
  غير الأدمن (18_media_admin_only.sql) — والصورة والنص والملصق للجميع.
• حماية لوحة الإدارة: للأدمن فقط — بوابة admin_panel_access() + سجلّ تدقيق لكل
  فتح أو محاولة، وسحب التنفيذ من الزائر (19_admin_panel_guard.sql). التطبيق يطلب
  كلمة مرور الحساب ويقفل اللوحة تلقائياً بعد ١٥ دقيقة.

للتحقق من نافذة الحذف بعد التنفيذ، الصق هذا في SQL Editor:
    select public.chat_delete_window_seconds();   -- المتوقّع: 180

أخطاء شائعة
-----------------------------------------------------------------
| already exists        | أعدت التنفيذ            | طبيعي وآمن — تجاوزه                 |
| syntax error near $$  | اللصق ناقص              | انسخ 00_ALL_IN_ONE.sql كاملاً        |
| لا يوجد مستخدم بهذا البريد | الحساب لم يُنشأ    | نفّذ الخطوة 3 ثم أعد المحاولة        |
