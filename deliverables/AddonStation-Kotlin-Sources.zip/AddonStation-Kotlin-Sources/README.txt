AddonStation — Kotlin source bundle
Generated: 2026-10-20

Requested source mapping:
- ChatScreenKt -> ui/chat/ChatScreen.kt
- ColorKt -> ui/theme/Color.kt
- ThemeKt -> ui/theme/Theme.kt
- Loading circle + network error state -> ui/components/Common.kt
  Functions: LoadingBox and ErrorState
- Error text mapping -> ui/ErrorText.kt
- Native crash/error report screen -> MainActivity.kt
  Function: showCrashReport
- Notifications page -> ui/account/AccountScreens.kt
  Function: NotificationsScreen
- Notification settings page (included for completeness) -> ui/settings/NotificationSettingsScreen.kt
- My Orders page -> ui/plans/PlansScreens.kt
  Function: MyOrdersScreen

These files are copied from the current working sources without modifying them.
