#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
يولّد **`supabase/99_VERIFY_ALL.sql`** — فاحص القاعدة الكامل (قراءة فقط).

ماذا يفعل الملف المُولَّد؟ يفحص بنداً بنداً أن كل ملفات SQL (01 → 46) نُفِّذت
كما نريد، ويطبع جدولاً: ✅/❌ + التفاصيل (وما هو المفقود بالاسم). يلصقه المالك
في Supabase → SQL Editor مرة واحدة.

لماذا مولّد؟ لأن الفاحص يجب أن يبقى مطابقاً لملفات الترحيل: أي ملف جديد
يُضاف بند له هنا ثم نُعيد التوليد. الفاحص `tools/check_verify_sql.py` يتحقّق
أن كل اسم/قيمة في الملف المُولَّد موجودة فعلاً في ملفات الترحيل (فلا أخطاء
إملائية ولا قيم مخترعة).

الاستخدام:
    python3 tools/make_verify_sql.py
"""
import io
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CHECKS = []          # (n, file, item, ok_sql, detail_sql)
_counter = [0]


def add(f, item, ok, detail):
    _counter[0] += 1
    CHECKS.append((_counter[0], f, item, ok, detail))


def arr(names):
    return "array[" + ", ".join("'" + n + "'" for n in names) + "]"


def q(sql):
    """يلفّ استعلاماً في الدالة التشخيصية: يرجع NULL إن كان الجدول/العمود مفقوداً."""
    sql = " ".join(sql.split())
    assert "$q$" not in sql
    return "public.diag_text($q$" + sql + "$q$)"


def q_ok(sql, expect="true"):
    """شرط: نتيجة الاستعلام النصّية تساوي المتوقَّع (كل فحوصنا ترجع 'true'/'false')."""
    assert expect in ("true", "false"), "القيم المتوقّعة نصّية فقط"
    return f"{q(sql)} = '{expect}'"


def qdet(sql, fallback="مفقود"):
    """تفاصيل آمنة: تسرد «مفقود» إن لم يوجد الجدول/العمود."""
    return f"coalesce({q(sql)}, '{fallback}')"


def qbool(sql):
    """شرط منطقي آمن: الاستعلام مصبوب ::text داخل نصّه، ويُقرأ false (⇒ ❌) إن فشل."""
    return f"coalesce({q(sql)}, 'false') = 'true'"


def missing_list(f, item, names, cond, label):
    """بند واحد يفحص مجموعة أسماء (جداول/دوال/سياسات) ويسرد المفقود منها."""
    a = arr(names)
    ok = f"(select count(*) from unnest({a}) t where {cond}) = 0"
    det = (f"coalesce((select 'المفقود: ' || string_agg(t, ' · ') from unnest({a}) t "
           f"where {cond}), '{label}')")
    add(f, item, ok, det)


# ═══════════════════════════════════════════════════════════════════════════
#  01_schema.sql
# ═══════════════════════════════════════════════════════════════════════════
TABLES = ["profiles", "subscription_plans", "payment_method_settings", "payment_orders",
          "content_items", "content_favorites", "content_downloads", "ac_wallets",
          "ac_transactions", "ac_tasks", "ac_task_claims", "ac_events", "chat_channels",
          "chat_messages", "chat_reactions", "chat_mutes", "chat_bans", "chat_reports",
          "chat_notifications", "chat_read_state", "chat_typing", "chat_rules",
          "chat_rule_acceptances", "user_friends", "creator_applications",
          "creator_submissions", "featured_creators", "creator_follows", "creator_tips",
          "site_assets", "sticker_packs", "app_settings", "admin_audit_log"]
missing_list("01_schema", f"الجداول الأساسية ({len(TABLES)})", TABLES,
             "to_regclass('public.' || t) is null", f"{len(TABLES)}/{len(TABLES)} موجودة")

add("01_schema", "عمودا التقسيم في site_assets (collection · collection_order)",
    q_ok("select (count(*) = 2)::text from information_schema.columns "
         "where table_schema = 'public' and table_name = 'site_assets' "
         "and column_name in ('collection', 'collection_order')", "true"),
    q("select coalesce(string_agg(column_name, ' · '), 'مفقود') from information_schema.columns "
      "where table_schema = 'public' and table_name = 'site_assets' "
      "and column_name in ('collection', 'collection_order')"))

add("01_schema", "أعمدة ملف المستخدم الأساسية (avatar_url · banner_url · role · plan · equipped_item_id …)",
    q_ok("select (count(*) = 8)::text from information_schema.columns "
         "where table_schema = 'public' and table_name = 'profiles' and column_name in "
         "('avatar_url', 'role', 'plan', 'plan_expires_at', 'equipped_item_id', 'username', "
         "'display_name', 'banner_url')", "true"),
    q("select count(*)::text || '/8' from information_schema.columns "
      "where table_schema = 'public' and table_name = 'profiles' and column_name in "
      "('avatar_url', 'role', 'plan', 'plan_expires_at', 'equipped_item_id', 'username', "
      "'display_name', 'banner_url')"))

add("01_schema", "دوال ومشغّلات الملف الشخصي (ترتيب الخطط · اللمس · الحماية)",
    "(select count(*) from unnest(array['plan_rank', 'role_rank', 'touch_updated_at', "
    "'guard_profile_update', 'handle_new_user']) t where not exists ("
    "select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
    "where n.nspname = 'public' and p.proname = t)) = 0 "
    "and (select count(*) from pg_trigger where not tgisinternal and tgname in "
    "('trg_guard_profile_update', 'on_auth_user_created', 'trg_touch_profiles', "
    "'trg_touch_subscription_plans', 'trg_touch_payment_orders', 'trg_touch_content_items', "
    "'trg_touch_app_settings', 'trg_touch_user_friends')) = 8",
    "coalesce((select 'المفقود: ' || string_agg(t, ' · ') "
    "from unnest(array['plan_rank', 'role_rank', 'touch_updated_at', "
    "'guard_profile_update', 'handle_new_user']) t where not exists ("
    "select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
    "where n.nspname = 'public' and p.proname = t)), '5/5 دوال') "
    "|| ' · المشغّلات: ' || (select count(*) from pg_trigger where not tgisinternal "
    "and tgname in ('trg_guard_profile_update', 'on_auth_user_created', "
    "'trg_touch_profiles', 'trg_touch_subscription_plans', 'trg_touch_payment_orders', "
    "'trg_touch_content_items', 'trg_touch_app_settings', 'trg_touch_user_friends'))::text "
    "|| '/8'")

add("01_schema", "فهارس الشات والأصول",
    q_ok("select (count(*) >= 5)::text from pg_indexes where schemaname = 'public' "
         "and indexname in ('chat_messages_channel_idx', 'chat_messages_thread_idx', "
         "'profiles_role_idx', 'site_assets_collection_idx', 'site_assets_file_url_uidx')", "true"),
    q("select count(*)::text || '/5' from pg_indexes where schemaname = 'public' "
      "and indexname in ('chat_messages_channel_idx', 'chat_messages_thread_idx', "
      "'profiles_role_idx', 'site_assets_collection_idx', 'site_assets_file_url_uidx')"))

# ═══════════════════════════════════════════════════════════════════════════
#  02 · 03 — دوال القاعدة
# ═══════════════════════════════════════════════════════════════════════════
FUNCS_CORE = ["current_role_of", "is_admin", "is_staff", "effective_plan", "effective_plan_label",
              "can_access_item", "download_limit_reached", "record_content_view",
              "record_content_download", "toggle_favorite", "ac_unlock_content", "ac_claim_task",
              "ac_admin_adjust", "ac_admin_grant_all", "create_payment_order",
              "submit_payment_receipt", "approve_payment_order", "reject_payment_order",
              "admin_update_profile", "set_profile_asset", "update_my_profile",
              "admin_upsert_content", "admin_delete_content", "admin_update_plan",
              "admin_upsert_payment_method", "admin_delete_payment_method", "admin_stats"]
missing_list("02_functions_core", f"دوال النواة ({len(FUNCS_CORE)})", FUNCS_CORE,
             "not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
             "where n.nspname = 'public' and p.proname = t)", f"{len(FUNCS_CORE)}/{len(FUNCS_CORE)} موجودة")

FUNCS_CHAT = ["app_setting", "chat_content_check", "send_chat_message",
              "chat_delete_window_seconds", "chat_delete_my_message", "chat_moderate_message",
              "chat_toggle_pin", "chat_toggle_reaction", "chat_mute_user", "chat_unmute_user",
              "chat_ban_user", "chat_unban_user", "chat_report_message", "chat_close_report",
              "chat_admin_upsert_room", "chat_admin_delete_room", "chat_send_announcement",
              "chat_set_typing", "chat_mark_read", "chat_unread_counts", "my_chat_status",
              "chat_accept_rules", "mark_notifications_read", "send_friend_request",
              "respond_friend_request", "submit_creator_application", "review_creator_application",
              "toggle_featured_creator", "creator_submit_content", "review_creator_submission",
              "creator_submit_tip", "creator_review_tip", "admin_update_settings",
              "admin_update_chat_rules"]
missing_list("03_functions_chat", f"دوال الشات والمبدعين ({len(FUNCS_CHAT)})", FUNCS_CHAT,
             "not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
             "where n.nspname = 'public' and p.proname = t)", f"{len(FUNCS_CHAT)}/{len(FUNCS_CHAT)} موجودة")

# ═══════════════════════════════════════════════════════════════════════════
#  04_rls.sql — سياسات الحماية
# ═══════════════════════════════════════════════════════════════════════════
POLICIES = [("profiles_select_all", "profiles"), ("profiles_update_own", "profiles"),
            ("profiles_admin_all", "profiles"), ("plans_select", "subscription_plans"),
            ("plans_admin_write", "subscription_plans"),
            ("pms_select_enabled", "payment_method_settings"),
            ("pms_admin_write", "payment_method_settings"),
            ("orders_select_own", "payment_orders"),
            ("content_select_public", "content_items"),
            ("content_admin_write", "content_items"),
            ("fav_own", "content_favorites"), ("downloads_own", "content_downloads"),
            ("ac_wallet_own", "ac_wallets"), ("ac_tx_own", "ac_transactions"),
            ("ac_tasks_read", "ac_tasks"), ("ac_tasks_admin", "ac_tasks"),
            ("ac_claims_own", "ac_task_claims"), ("ac_events_admin", "ac_events"),
            ("channels_read", "chat_channels"), ("channels_admin", "chat_channels"),
            ("messages_read", "chat_messages"), ("reactions_read", "chat_reactions"),
            ("reactions_own", "chat_reactions"), ("reactions_delete_own", "chat_reactions"),
            ("mutes_read", "chat_mutes"), ("mutes_staff_write", "chat_mutes"),
            ("bans_read", "chat_bans"), ("bans_staff_write", "chat_bans"),
            ("reports_read", "chat_reports"), ("reports_insert", "chat_reports"),
            ("reports_staff_update", "chat_reports"),
            ("rule_accept_own", "chat_rule_acceptances"),
            ("rule_accept_insert", "chat_rule_acceptances"),
            ("rules_read", "chat_rules"), ("rules_admin", "chat_rules"),
            ("typing_read", "chat_typing"), ("typing_own", "chat_typing"),
            ("read_state_own", "chat_read_state"), ("notif_own", "chat_notifications"),
            ("notif_update_own", "chat_notifications"), ("friends_own", "user_friends"),
            ("apps_own", "creator_applications"), ("apps_insert", "creator_applications"),
            ("submissions_own", "creator_submissions"),
            ("submissions_admin_write", "creator_submissions"),
            ("featured_read", "featured_creators"), ("featured_admin", "featured_creators"),
            ("follows_read", "creator_follows"), ("follows_own", "creator_follows"),
            ("tips_read", "creator_tips"), ("tips_admin_write", "creator_tips"),
            ("assets_read", "site_assets"), ("assets_admin", "site_assets"),
            ("packs_read", "sticker_packs"), ("packs_admin", "sticker_packs"),
            ("settings_read", "app_settings"), ("audit_admin_read", "admin_audit_log")]
missing_list("04_rls", f"سياسات RLS ({len(POLICIES)})",
             [f"{p}:{t}" for p, t in POLICIES],
             "not exists (select 1 from pg_policies pol where pol.schemaname = 'public' "
             "and pol.tablename = split_part(t, ':', 2) and pol.policyname = split_part(t, ':', 1))",
             f"{len(POLICIES)}/{len(POLICIES)} موجودة")

# ═══════════════════════════════════════════════════════════════════════════
#  05_storage.sql — المخازن وسياساتها
# ═══════════════════════════════════════════════════════════════════════════
BUCKETS = ["content-files", "payment-receipts", "chat-images", "chat-media",
           "creator-media", "site-assets", "admin-assets"]
add("05_storage · 40_admin_asset_privacy", f"المخازن السبعة (منها admin-assets الخاص)",
    q_ok("select (count(*) = 7)::text from storage.buckets where id in "
         "('content-files', 'payment-receipts', 'chat-images', 'chat-media', "
         "'creator-media', 'site-assets', 'admin-assets')", "true"),
    qdet("select string_agg(id, ' · ') from storage.buckets where id in "
         "('content-files', 'payment-receipts', 'chat-images', 'chat-media', "
         "'creator-media', 'site-assets', 'admin-assets')"))

add("05_storage", "مخزن site-assets عام (public) — الصور العادية تظهر بلا تسجيل دخول",
    q_ok("select (count(*) = 1)::text from storage.buckets where id = 'site-assets' and public", "true"),
    qdet("select 'public = ' || public::text from storage.buckets where id = 'site-assets'"))

add("40_admin_asset_privacy", "مخزن admin-assets خاص (public = false)",
    q_ok("select (count(*) = 1)::text from storage.buckets where id = 'admin-assets' and not public", "true"),
    qdet("select 'public = ' || public::text from storage.buckets where id = 'admin-assets'"))

STORAGE_POLICIES = ["content_files_read", "content_files_admin_write",
                    "content_files_admin_update", "content_files_admin_delete",
                    "receipts_insert_own", "receipts_read", "receipts_update_own",
                    "chat_images_insert", "chat_images_read", "chat_media_insert",
                    "chat_media_read", "creator_media_insert", "creator_media_read",
                    "site_assets_read", "site_assets_admin_write", "site_assets_creator_write",
                    "site_assets_admin_update", "site_assets_admin_delete",
                    "admin_assets_read", "admin_assets_insert", "admin_assets_update",
                    "admin_assets_delete"]
add("05_storage · 40_admin_asset_privacy", f"سياسات المخزن ({len(STORAGE_POLICIES)})",
    q_ok("select (count(*) = %d)::text from pg_policies where schemaname = 'storage' "
         "and policyname in (%s)" % (len(STORAGE_POLICIES),
                                     ", ".join("'%s'" % p for p in STORAGE_POLICIES)), "true"),
    q("select count(*)::text || '/%d' from pg_policies where schemaname = 'storage' "
      "and policyname in (%s)" % (len(STORAGE_POLICIES),
                                  ", ".join("'%s'" % p for p in STORAGE_POLICIES))))

# ═══════════════════════════════════════════════════════════════════════════
#  06_seed · 08_admin_bootstrap
# ═══════════════════════════════════════════════════════════════════════════
add("06_seed · 22_plan_prices", "الخطط الثلاث وأسعارها (free · epic · legendary)",
    q_ok("select (count(*) = 3)::text from public.subscription_plans "
         "where id in ('free', 'epic', 'legendary')", "true"),
    qdet("select string_agg(id || ' = ' || price_lyd::text || ' د.ل / $' || price_usd::text, "
         "' · ' order by sort_order) from public.subscription_plans"))

add("22_plan_prices", "سعرا Epic و Legendary بالدولار مضبوطان (2.99 · 5.99)",
    qbool("select (count(*) = 2)::text from public.subscription_plans "
          "where (id = 'epic' and price_usd = 2.99) "
          "or (id = 'legendary' and price_usd = 5.99)"),
    qdet("select string_agg(id || ' = $' || price_usd::text, ' · ' order by sort_order) "
         "from public.subscription_plans"))

add("08_admin_bootstrap", "يوجد حساب إدارة واحد على الأقل (role = admin)",
    q_ok("select (count(*) >= 1)::text from public.profiles where role = 'admin'", "true"),
    qdet("select count(*)::text || ' حساب إدارة' from public.profiles where role = 'admin'"))

# ═══════════════════════════════════════════════════════════════════════════
#  09 · 10 · 11
# ═══════════════════════════════════════════════════════════════════════════
missing_list("09_gateway_functions", "دوال البوابات (gateway)",
             ["gateway_confirm_order", "gateway_attach_session"],
             "not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
             "where n.nspname = 'public' and p.proname = t)", "2/2 موجودة")

add("10_realtime", "منشور البث الحيّ supabase_realtime موجود",
    q_ok("select (count(*) = 1)::text from pg_publication where pubname = 'supabase_realtime'", "true"),
    q("select string_agg(pubname, ' · ') from pg_publication "
      "where pubname = 'supabase_realtime'"))

RT_TABLES = ["chat_messages", "chat_reactions", "chat_typing", "chat_read_state",
             "chat_notifications", "profiles"]
missing_list("10_realtime", f"جداول البث الحيّ ({len(RT_TABLES)})",
             RT_TABLES,
             "not exists (select 1 from pg_publication_rel pr join pg_publication p on p.oid = pr.prpubid "
             "join pg_class c on c.oid = pr.prrelid where p.pubname = 'supabase_realtime' "
             "and c.relname = t)", f"{len(RT_TABLES)}/{len(RT_TABLES)} في المنشور")

add("11_grants", "صلاحيات الكتابة للأدوار (service_role يكتب · authenticated يقرأ)",
    q_ok("select ((has_table_privilege('service_role', 'public.site_assets', 'insert') "
         "and has_table_privilege('authenticated', 'public.site_assets', 'select')))::text", "true"),
    qdet("select 'service_role insert = ' || has_table_privilege('service_role', 'public.site_assets', 'insert')::text "
         "|| ' · authenticated select = ' || has_table_privilege('authenticated', 'public.site_assets', 'select')::text"))

# ═══════════════════════════════════════════════════════════════════════════
#  13_channels_icons · 16_language_room_names · 17_cash_services_room
# ═══════════════════════════════════════════════════════════════════════════
add("13_channels_icons", "أسماء الغرف الرسمية صحيحة (General · Minecraft · العربية …)",
    "(" + q_ok("select (count(*) >= 5)::text from public.chat_channels where id in "
               "('general', 'minecraft', 'support', 'lang-ar', 'lang-ru')")
    + " and " + q_ok("select (name = 'العربية')::text from public.chat_channels "
                     "where id = 'lang-ar'") + ")",
    qdet("select string_agg(id || ' → ' || name, ' · ' order by sort_order) "
         "from public.chat_channels where category = 'lang'"))

add("16_language_room_names", "الاسم العربي للغرفة = «العربية»",
    q_ok("select (name = 'العربية')::text from public.chat_channels where id = 'lang-ar'", "true"),
    qdet("select name || ' · ' || coalesce(description, '—') from public.chat_channels "
         "where id = 'lang-ar'"))

add("17_cash_services_room", "غرفة «خدمات النقدية» موجودة والكتابة فيها للإدارة فقط (admin_only)",
    q_ok("select ((post_permission = 'admin_only') and is_locked)::text "
         "from public.chat_channels where id = 'cash-services'", "true"),
    qdet("select name || ' · الكتابة: ' || post_permission || ' · مقفلة: ' || is_locked::text "
         "from public.chat_channels where id = 'cash-services'", "مفقودة"))

# ═══════════════════════════════════════════════════════════════════════════
#  14_redeem_codes
# ═══════════════════════════════════════════════════════════════════════════
missing_list("14_redeem_codes", "جداول أكواد الشحن",
             ["ac_redeem_codes", "ac_redeem_uses"],
             "to_regclass('public.' || t) is null", "2/2 موجودة")
missing_list("14_redeem_codes", "دوال أكواد الشحن",
             ["ac_random_code", "ac_admin_create_codes", "ac_redeem_code"],
             "not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
             "where n.nspname = 'public' and p.proname = t)", "3/3 موجودة")
missing_list("14_redeem_codes", "سياسات أكواد الشحن",
             ["ac_redeem_codes_admin:ac_redeem_codes", "ac_redeem_uses_self:ac_redeem_uses"],
             "not exists (select 1 from pg_policies pol where pol.schemaname = 'public' "
             "and pol.tablename = split_part(t, ':', 2) and pol.policyname = split_part(t, ':', 1))",
             "2/2 موجودة")

# ═══════════════════════════════════════════════════════════════════════════
#  15_assets_v2 (+16_fix_asset_paths) + 21_banners + 27_admin_only_assets
# ═══════════════════════════════════════════════════════════════════════════
COLLECTIONS = [("PFP", 1), ("Default", 1), ("Profiles", 24), ("Profile 2", 11),
               ("Best Cartoon", 7), ("Cartoon Meme", 11), ("Cool Cartoon", 6),
               ("Call Of Duty", 10), ("Sad", 10), ("Ahh", 8), ("Moumen", 4),
               ("Animated", 8), ("Memes", 47), ("Minecraft Memes 1", 21),
               ("Minecraft Memes 2", 87), ("Minecraft Memes 3", 20),
               ("Minecraft Movie", 6), ("Top", 12), ("Minecraft Items", 103),
               ("Games", 41), ("PlayStation", 10), ("Random Things", 22),
               ("Nature 🌿", 13), ("Random 🎲", 27)]
COLLECTION_VALUES = ",\n              ".join(
    f"('{c}', {n})" for c, n in COLLECTIONS)
TOTAL_ASSETS = sum(n for _, n in COLLECTIONS)
TYPE_MIN = {"avatar": 101, "item": 176, "sticker": 193, "banner": 40}

# نُقارن بعدد **لا ينقص** عن دفعاتنا: أي زيادة = أصول أضفتها أنت من لوحة الإدارة
# (مثل بانرين إضافيين) — وهذا لا يُعدّ نقصاً، بل يُذكر في التفاصيل.
TYPE_CHECKS = " and ".join(
    f"(count(*) filter (where asset_type = '{t}') >= {n})"
    for t, n in TYPE_MIN.items())

add("15_assets_v2 · 21_banners · 45 · 46", f"مجموع الأصول >= {TOTAL_ASSETS} (101 أفاتاراً بعد استبدال الحزمتين + 409 أصول أخرى)",
    q_ok(f"select (count(*) >= {TOTAL_ASSETS})::text from public.site_assets", "true"),
    qdet(f"select count(*)::text || '/{TOTAL_ASSETS} مصدر' "
         "|| ' · إضافاتك: ' || greatest(count(*) - " + str(TOTAL_ASSETS) + ", 0)::text "
         "from public.site_assets"))

add("15_assets_v2 · 45 · 46", "توزيع الأصول كاملًا (101 أفاتاراً · 176 أداة · 193 ملصقاً · 40 بانراً)",
    q_ok(f"select ({TYPE_CHECKS})::text from public.site_assets", "true"),
    qdet("select 'avatar ' || count(*) filter (where asset_type = 'avatar')::text "
         "|| ' · item ' || count(*) filter (where asset_type = 'item')::text "
         "|| ' · sticker ' || count(*) filter (where asset_type = 'sticker')::text "
         "|| ' · banner ' || count(*) filter (where asset_type = 'banner')::text "
         "from public.site_assets"))

# قسمٌ قسمٌ: لا نقص في أي قسم من أقسام دفعاتنا (الزيادة مقبولة = إضافاتك)
add("15_assets_v2 · 21_banners", f"لا نقص في أي قسم من أقسام الدفعات ({len(COLLECTIONS)} قسماً)",
    q_ok(f"""(select (count(*) = 0)::text
            from (values
              {COLLECTION_VALUES}) as e(collection, want)
            left join (select collection, count(*) as have
                         from public.site_assets
                        where collection is not null
                        group by collection) a on a.collection = e.collection
           where coalesce(a.have, 0) < e.want)""", "true"),
    qdet(f"""select string_agg(e.collection || ': ' || coalesce(a.have, 0) || '/' || e.want, ' · ')
              from (values
                {COLLECTION_VALUES}) as e(collection, want)
              left join (select collection, count(*) as have
                           from public.site_assets
                          where collection is not null
                          group by collection) a on a.collection = e.collection
             where coalesce(a.have, 0) < e.want""", "لا نقص في أي قسم"))

# الحزمتان الجديدتان: نقرأ المسارات والبصمات من البيان المثبّت نفسه الذي ولّد 46.
with io.open(os.path.join(ROOT, "supabase", "profile-packs.json"), encoding="utf-8") as _profile_fh:
    PROFILE_PACK_ASSETS = json.load(_profile_fh)["assets"]
PROFILE_PACK_DB_VALUES = ", ".join(
    "('{path}', '{collection}', '{plan}')".format(
        path=a["path"].replace("'", "''"),
        collection=a["collection"].replace("'", "''"),
        plan=a["plan"].replace("'", "''"),
    )
    for a in PROFILE_PACK_ASSETS
)
PROFILE_PACK_STORAGE_VALUES = ", ".join(
    "('{path}', {size}::bigint, '{md5}')".format(
        path=a["path"].replace("'", "''"), size=a["bytes"], md5=a["md5"])
    for a in PROFILE_PACK_ASSETS
)

add("46_profile_avatar_packs", "حزمة Profiles = 24 Epic وحزمة Profile 2 = 11 Legendary بالضبط",
    q_ok("select (((count(*) filter (where collection = 'Profiles')) = 24) and "
         "((count(*) filter (where collection = 'Profiles' and required_plan = 'epic' and enabled)) = 24) and "
         "((count(*) filter (where collection = 'Profile 2')) = 11) and "
         "((count(*) filter (where collection = 'Profile 2' and required_plan = 'legendary' and enabled)) = 11))::text "
         "from public.site_assets where asset_type = 'avatar'", "true"),
    qdet("select string_agg(collection || '/' || required_plan || '=' || total::text, ' · ' order by collection, required_plan) "
         "from (select collection, required_plan, count(*) total from public.site_assets "
         "where asset_type = 'avatar' and collection in ('Profiles', 'Profile 2') "
         "group by collection, required_plan) s"))

add("46_profile_avatar_packs", "كل مسارات الحزمتين الـ35 مسجّلة بالخطة والقسم الصحيحين",
    q_ok(f"select (count(*) = 0)::text from (values {PROFILE_PACK_DB_VALUES}) e(path, collection, plan) "
         "left join public.site_assets a on a.file_url = e.path and a.asset_type = 'avatar' "
         "where a.id is null or not a.enabled or a.collection <> e.collection or a.required_plan <> e.plan", "true"),
    qdet(f"select string_agg(e.path, ' · ') from (values {PROFILE_PACK_DB_VALUES}) e(path, collection, plan) "
         "left join public.site_assets a on a.file_url = e.path and a.asset_type = 'avatar' "
         "where a.id is null or not a.enabled or a.collection <> e.collection or a.required_plan <> e.plan",
         "كل المسارات مطابقة"))

add("46_profile_avatar_packs", "ملفات الحزمتين الـ35 في Storage مطابقة للحجم والبصمة المثبّتَين",
    q_ok(f"select (count(*) = 0)::text from (values {PROFILE_PACK_STORAGE_VALUES}) e(path, bytes, md5) "
         "left join storage.objects o on o.bucket_id = 'site-assets' and o.name = e.path "
         "where o.id is null or coalesce((o.metadata->>'size')::bigint, -1) <> e.bytes "
         "or trim(both '\"' from coalesce(o.metadata->>'eTag', '')) <> e.md5", "true"),
    qdet(f"select string_agg(e.path, ' · ') from (values {PROFILE_PACK_STORAGE_VALUES}) e(path, bytes, md5) "
         "left join storage.objects o on o.bucket_id = 'site-assets' and o.name = e.path "
         "where o.id is null or coalesce((o.metadata->>'size')::bigint, -1) <> e.bytes "
         "or trim(both '\"' from coalesce(o.metadata->>'eTag', '')) <> e.md5",
         "35/35 ملفاً مطابقاً"))

# المصدر المرجعي: الملفات المرفوعة في المخزن. المسار المكرّر (profiles/profiles/…)
# ليس خطأً — هكذا رُفعت الملفات فعلاً؛ لذلك نُقارن **بعد تطبيع البادئة المكرّرة**
# من الطرفين، فالسؤال الصحيح: «هل كل صورة معروضة لها ملف في المخزن؟»
NORM = "regexp_replace(%s, '^(profiles|banners|items|stickers)/(\\1)/', '\\1/')"
ASSET_BUCKET = "case when a.file_url like 'admin-private/%' then 'admin-assets' else 'site-assets' end"
PROFILE_BUCKET = "case when p.avatar_url like 'admin-private/%' then 'admin-assets' else 'site-assets' end"

add("15_assets_v2 · 21_banners · 40",  "كل أصل مفعّل ملفه موجود في المخزن (لا صورة مكسورة)",
    q_ok("select (count(*) = 0)::text from public.site_assets a "
         "where a.enabled and not exists (select 1 from storage.objects o "
         "where o.bucket_id = " + ASSET_BUCKET + " and "
         + NORM % "o.name" + " = " + NORM % "a.file_url" + ")", "true"),
    qdet("select 'أول المفقود: ' || string_agg(a.file_url, ' · ') from ("
         "select a.file_url from public.site_assets a "
         "where a.enabled and not exists (select 1 from storage.objects o "
         "where o.bucket_id = " + ASSET_BUCKET + " and "
         + NORM % "o.name" + " = " + NORM % "a.file_url" + ") limit 6) a",
         "كل الملفات موجودة"))

add("15_assets_v2", "كل أفاتار مفعّل ملفه موجود في المخزن",
    q_ok("select (count(*) = 0)::text from public.site_assets a "
         "where a.enabled and a.asset_type = 'avatar' and not exists ("
         "select 1 from storage.objects o where o.bucket_id = " + ASSET_BUCKET + " and "
         + NORM % "o.name" + " = " + NORM % "a.file_url" + ")", "true"),
    qdet("select string_agg(a.file_url, ' · ') from ("
         "select a.file_url from public.site_assets a "
         "where a.enabled and a.asset_type = 'avatar' and not exists ("
         "select 1 from storage.objects o where o.bucket_id = " + ASSET_BUCKET + " and "
         + NORM % "o.name" + " = " + NORM % "a.file_url" + ") limit 6) a",
         "كل الأفاتارات موجودة"))

add("24_free_default_avatar · 32", "صور الحسابات موجودة في المخزن (لا حساب بصورة مكسورة)",
    q_ok("select (count(*) = 0)::text from public.profiles p "
         "where p.avatar_url is not null and btrim(p.avatar_url) <> '' "
         "and lower(btrim(p.avatar_url)) <> 'none' and not exists ("
         "select 1 from storage.objects o where o.bucket_id = " + PROFILE_BUCKET + " and "
         + NORM % "o.name" + " = " + NORM % "p.avatar_url" + ")", "true"),
    qdet("select count(*)::text || ' حساباً' from public.profiles p "
         "where p.avatar_url is not null and btrim(p.avatar_url) <> '' "
         "and lower(btrim(p.avatar_url)) <> 'none' and not exists ("
         "select 1 from storage.objects o where o.bucket_id = " + PROFILE_BUCKET + " and "
         + NORM % "o.name" + " = " + NORM % "p.avatar_url" + ")", "كل صور الحسابات موجودة"))

add("21_banners", "بانرات إضافية مسجّلة (40)",
    q_ok("select (count(*) >= 40)::text from public.site_assets where asset_type = 'banner'", "true"),
    qdet("select count(*)::text || ' بانر' from public.site_assets where asset_type = 'banner'"))

add("27_admin_only_assets", "أصول حصرية للإدارة (required_plan = admin)",
    q_ok("select (count(*) >= 1)::text from public.site_assets where required_plan = 'admin'", "true"),
    qdet("select count(*)::text || ' أصلاً' from public.site_assets where required_plan = 'admin'"))

add("40_admin_asset_privacy", "عرض visible_profiles ودالة تنقيح أصل الأدمن موجودان",
    q_ok("select (to_regclass('public.visible_profiles') is not null and exists ("
         "select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'is_admin_only_profile_asset'))::text", "true"),
    qdet("select 'view=' || (to_regclass('public.visible_profiles') is not null)::text "
         "|| ' · function=' || exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'is_admin_only_profile_asset')::text"))

add("40_admin_asset_privacy", "لا قراءة REST مباشرة لـ profiles؛ القراءة من العرض المنقّح",
    q_ok("select ((not has_table_privilege('anon', 'public.profiles', 'select')) "
         "and (not has_table_privilege('authenticated', 'public.profiles', 'select')) "
         "and has_table_privilege('anon', 'public.visible_profiles', 'select') "
         "and has_table_privilege('authenticated', 'public.visible_profiles', 'select') "
         "and not has_column_privilege('authenticated', 'public.profiles', 'equipped_item_id', 'update'))::text", "true"),
    qdet("select 'base anon=' || has_table_privilege('anon', 'public.profiles', 'select')::text "
         "|| ' · base auth=' || has_table_privilege('authenticated', 'public.profiles', 'select')::text "
         "|| ' · view anon=' || has_table_privilege('anon', 'public.visible_profiles', 'select')::text "
         "|| ' · view auth=' || has_table_privilege('authenticated', 'public.visible_profiles', 'select')::text "
         "|| ' · equipped direct update=' || has_column_privilege('authenticated', 'public.profiles', "
         "'equipped_item_id', 'update')::text"))

add("40_admin_asset_privacy", "سياسة site_assets تخفي required_plan=admin عن غير الأدمن",
    q_ok("select coalesce((select (qual ilike '%required_plan%' and qual ilike '%is_admin%')::text "
         "from pg_policies where schemaname = 'public' and tablename = 'site_assets' "
         "and policyname = 'assets_read'), 'false')", "true"),
    qdet("select qual from pg_policies where schemaname = 'public' and tablename = 'site_assets' "
         "and policyname = 'assets_read'"))

add("40_admin_asset_privacy", "كل ملفات admin في المخزن الخاص ولا نسخة عامة منها",
    q_ok("select (count(*) >= 1 and count(*) filter (where file_url not like 'admin-private/%' "
         "or not exists (select 1 from storage.objects o where o.bucket_id = 'admin-assets' and o.name = a.file_url) "
         "or exists (select 1 from storage.objects o where o.bucket_id = 'site-assets' "
         "and o.name = regexp_replace(a.file_url, '^admin-private/', ''))) = 0)::text "
         "from public.site_assets a where required_plan = 'admin'", "true"),
    qdet("select count(*)::text || ' admin · ينتظر النقل/التنظيف: ' || "
         "count(*) filter (where file_url not like 'admin-private/%' "
         "or not exists (select 1 from storage.objects o where o.bucket_id = 'admin-assets' and o.name = a.file_url) "
         "or exists (select 1 from storage.objects o where o.bucket_id = 'site-assets' "
         "and o.name = regexp_replace(a.file_url, '^admin-private/', '')))::text "
         "from public.site_assets a where required_plan = 'admin'"))

# ═══════════════════════════════════════════════════════════════════════════
#  17 · 18 · 19 · 20 · 23 · 24 · 25 · 26 · 29 · 30 · 31 · 40
# ═══════════════════════════════════════════════════════════════════════════
add("17_message_delete_window", "نافذة حذف الرسالة = 180 ثانية (٣ دقائق)",
    q_ok("select (public.chat_delete_window_seconds() = 180)::text", "true"),
    q("select public.chat_delete_window_seconds()::text || ' ثانية'"))

add("18_media_admin_only", "الوسائط (فيديو/صوت) للإدارة فقط — الحارس والزناد",
    q_ok("select ((select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'chat_media_admin_only_guard') = 1 "
         "and (select count(*) from pg_trigger where tgname = 'trg_chat_media_admin_only' "
         "and not tgisinternal) = 1)::text", "true"),
    q("select 'دالة الحارس: ' || ((select count(*) from pg_proc p join pg_namespace n "
      "on n.oid = p.pronamespace where n.nspname = 'public' "
      "and p.proname = 'chat_media_admin_only_guard')::text) || ' · الزناد: ' "
      "|| ((select count(*) from pg_trigger where tgname = 'trg_chat_media_admin_only' "
      "and not tgisinternal)::text)"))

add("19_admin_panel_guard", "دالة حماية لوحة الإدارة + سياساتها",
    q_ok("select ((select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'admin_panel_access') = 1 "
         "and (select count(*) from pg_policies where schemaname = 'public' "
         "and policyname in ('settings_admin', 'audit_admin_read', 'ac_redeem_codes_admin', "
         "'orders_admin_all')) = 4)::text", "true"),
    q("select 'الدالة: ' || ((select count(*) from pg_proc p join pg_namespace n "
      "on n.oid = p.pronamespace where n.nspname = 'public' "
      "and p.proname = 'admin_panel_access')::text) || ' · السياسات: ' "
      "|| ((select count(*) from pg_policies where schemaname = 'public' "
      "and policyname in ('settings_admin', 'audit_admin_read', 'ac_redeem_codes_admin', "
      "'orders_admin_all'))::text) || '/4'"))

add("20_sticker_with_text", "send_chat_message تقبل الملصق مع النص",
    q_ok("select (count(*) >= 1)::text from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'send_chat_message' "
         "and pg_get_function_arguments(p.oid) like '%p_sticker_url%'", "true"),
    q("select count(*)::text || ' نسخة' from pg_proc p join pg_namespace n "
      "on n.oid = p.pronamespace where n.nspname = 'public' "
      "and p.proname = 'send_chat_message' and pg_get_function_arguments(p.oid) like '%p_sticker_url%'"))

add("23_payment_order_usd", "عمود amount_usd ودالة الطلب ترجعه",
    q_ok("select ((select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'payment_orders' and column_name = 'amount_usd') = 1)::text", "true"),
    q("select 'amount_usd: ' || ((select count(*) from information_schema.columns "
      "where table_schema = 'public' and table_name = 'payment_orders' "
      "and column_name = 'amount_usd')::text)"))

add("24_free_default_avatar · 32", "افتراضي avatar_url = المسار المعتمد + زناد الحساب الجديد",
    q_ok("select ((select column_default like '%profiles/profiles/onefree.png%' "
         "from information_schema.columns where table_schema = 'public' "
         "and table_name = 'profiles' and column_name = 'avatar_url') "
         "and (select count(*) from pg_trigger where tgname = 'on_auth_user_created' "
         "and not tgisinternal) = 1)::text", "true"),
    q("select 'الافتراضي: ' || coalesce((select column_default from information_schema.columns "
      "where table_schema = 'public' and table_name = 'profiles' and column_name = 'avatar_url'), 'مفقود')"))

add("25_fix_send_chat_message_unnest", "send_chat_message بلا خطأ unnest (الإصلاح مطبَّق)",
    q_ok("select (count(*) = 0)::text from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'send_chat_message' "
         "and pg_get_functiondef(p.oid) ilike '%where unnest is not null%'", "true"),
    q("select count(*)::text || ' نسخة فيها الخلل' from pg_proc p join pg_namespace n "
      "on n.oid = p.pronamespace where n.nspname = 'public' "
      "and p.proname = 'send_chat_message' and pg_get_functiondef(p.oid) ilike '%where unnest is not null%'"))

add("26_fix_site_assets_sequence", "تسلسل الأصول يعمل (authenticated يستطيع الإدراج)",
    qbool("select (has_sequence_privilege('authenticated', 'public.site_assets_id_seq', 'usage') "
          "and (select count(*) from pg_sequences where schemaname = 'public' "
          "and sequencename = 'site_assets_id_seq') = 1)::text"),
    qdet("select 'التسلسل: ' || coalesce((select sequencename from pg_sequences "
         "where schemaname = 'public' and sequencename = 'site_assets_id_seq'), 'مفقود') "
         "|| ' · أعلى معرّف: ' || coalesce((select max(id)::text from public.site_assets), '—')"))

add("29_chat_moderation_rooms", "غرف المشرفين + دوالها + سياساتها",
    q_ok("select ((select count(*) from information_schema.tables where table_schema = 'public' "
         "and table_name = 'chat_moderator_rooms') = 1 "
         "and (select count(*) from pg_policies where schemaname = 'public' "
         "and policyname in ('mod_rooms_admin_all', 'mod_rooms_self_read')) = 2 "
         "and (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname in ('chat_can_moderate_channel', "
         "'chat_my_moderation_scope', 'chat_delete_message_staff', 'chat_moderator_list', "
         "'chat_set_moderator_rooms')) = 5)::text", "true"),
    q("select 'الجدول: ' || ((select count(*) from information_schema.tables "
      "where table_schema = 'public' and table_name = 'chat_moderator_rooms')::text) "
      "|| ' · السياسات: ' || ((select count(*) from pg_policies "
      "where schemaname = 'public' and policyname in ('mod_rooms_admin_all', "
      "'mod_rooms_self_read'))::text) || '/2' "
      "|| ' · الدوال: ' || ((select count(*) from pg_proc p join pg_namespace n "
      "on n.oid = p.pronamespace where n.nspname = 'public' "
      "and p.proname in ('chat_can_moderate_channel', 'chat_my_moderation_scope', "
      "'chat_delete_message_staff', 'chat_moderator_list', 'chat_set_moderator_rooms'))::text) || '/5'"))

add("30_chat_members_only", "الشات للمسجّلين فقط (3 سياسات بـ auth.uid())",
    q_ok("select (count(*) = 3)::text from pg_policies where schemaname = 'public' "
         "and policyname in ('messages_read', 'reactions_read', 'channels_read') "
         "and qual ilike '%auth.uid()%'", "true"),
    q("select count(*)::text || '/3' from pg_policies where schemaname = 'public' "
      "and policyname in ('messages_read', 'reactions_read', 'channels_read') "
      "and qual ilike '%auth.uid()%'"))

add("31_single_free_avatar · 45 · 46", "سجل أفاتار مجاني واحد فقط في Default وملف onefree موجود",
    qbool("select (count(*) = 1 and bool_and(a.enabled) and bool_and(a.collection = 'Default') and "
          "bool_and(a.file_url = 'profiles/profiles/onefree.png') and bool_and(exists ("
          "select 1 from storage.objects o where o.bucket_id = 'site-assets' "
          "and o.name = a.file_url)))::text from public.site_assets a "
          "where a.asset_type = 'avatar' and a.required_plan = 'free'"),
    qdet("select count(*)::text || ' سجل مجاني · ' || "
         "coalesce(string_agg(file_url, ' · '), '—') from public.site_assets "
         "where asset_type = 'avatar' and required_plan = 'free'"))

add("32_onefree_canonical_path", "المسار المعتمد موحّد (الأصل المفعّل · الافتراضي · كل الحسابات)",
    q_ok("select ((select count(*) from public.site_assets where asset_type = 'avatar' "
         "and required_plan = 'free' and enabled "
         "and file_url = 'profiles/profiles/onefree.png') = 1 "
         "and (select column_default like '%profiles/profiles/onefree.png%' from "
         "information_schema.columns where table_schema = 'public' "
         "and table_name = 'profiles' and column_name = 'avatar_url') "
         "and (select count(*) from public.profiles "
         "where avatar_url = 'profiles/onefree.png') = 0)::text", "true"),
    qdet("select 'المفعّل: ' || coalesce((select string_agg(file_url, ' · ') "
         "from public.site_assets where asset_type = 'avatar' and required_plan = 'free' "
         "and enabled), '—') || ' · الافتراضي: ' || coalesce((select column_default "
         "from information_schema.columns where table_schema = 'public' "
         "and table_name = 'profiles' and column_name = 'avatar_url'), '—') "
         "|| ' · حسابات على مسار قديم: ' || (select count(*) from public.profiles "
         "where avatar_url = 'profiles/onefree.png')::text"))

add("33_user_block", "الحظر بين المستخدمين (سياسة جوجل UGC): الجدول + الدوال + إخفاء الرسائل",
    q_ok("select ((select count(*) from information_schema.tables where table_schema = 'public' "
         "and table_name = 'user_blocks') = 1 "
         "and (select count(*) from pg_proc where proname in "
         "('user_block', 'user_unblock', 'is_blocked_pair', 'my_blocked_users', "
         "'i_blocked_user')) = 5 "
         "and (select count(*) from pg_policies where schemaname = 'public' "
         "and tablename = 'chat_messages' and policyname = 'messages_read' "
         "and qual like '%is_blocked_pair%') = 1 "
         "and (select count(*) from pg_policies where schemaname = 'public' "
         "and tablename = 'user_blocks' and policyname = 'user_blocks_read') = 1)::text", "true"),
    qdet("select 'الجدول: ' || (select case when count(*) = 1 then 'موجود' else 'مفقود' end "
         "from information_schema.tables where table_schema = 'public' and table_name = 'user_blocks') "
         "|| ' · الدوال: ' || (select count(*) from pg_proc where proname in "
         "('user_block', 'user_unblock', 'is_blocked_pair', 'my_blocked_users', "
         "'i_blocked_user'))::text || '/5 ' "
         "|| '· إخفاء الرسائل: ' || (select case when count(*) = 1 then 'مفعّل' else 'غير مفعّل' end "
         "from pg_policies where schemaname = 'public' and tablename = 'chat_messages' "
         "and policyname = 'messages_read' and qual like '%is_blocked_pair%') "
         "|| ' · حظرات مسجّلة: ' || (select count(*) from public.user_blocks)::text"))
add("31_single_free_avatar · 45", "لا يوجد حساب بلا صورة افتراضية أو مخصّصة",
    qbool("select (count(*) = 0)::text from public.profiles where avatar_url is null "
          "or btrim(avatar_url) = ''"),
    qdet("select count(*)::text || ' بلا صورة' from public.profiles "
         "where avatar_url is null or btrim(avatar_url) = ''"))

add("45_single_attached_free_avatar", "لا توجد سجلات أفاتار مجانية قديمة",
    qbool("select (count(*) = 0)::text from public.site_assets "
          "where asset_type = 'avatar' and required_plan = 'free' "
          "and file_url <> 'profiles/profiles/onefree.png'"),
    qdet("select count(*)::text || ' سجل مجاني قديم' from public.site_assets "
         "where asset_type = 'avatar' and required_plan = 'free' "
         "and file_url <> 'profiles/profiles/onefree.png'"))

add("45_single_attached_free_avatar", "ملف صورة المالك موجود على المسار الوحيد المعتمد",
    q_ok("select (count(*) = 1)::text from storage.objects where bucket_id = 'site-assets' "
         "and name = 'profiles/profiles/onefree.png'", "true"),
    qdet("select string_agg(name || ' · ' || coalesce(metadata->>'size', '?') || ' bytes', ' · ') "
         "from storage.objects where bucket_id = 'site-assets' "
         "and name = 'profiles/profiles/onefree.png'", "غير مرفوع بعد"))

# ── معلوماتية: ملفات قديمة مُستبدَلة + حالة الشات ─────────────────────────
add("07_seed_assets · 12_avatars", "دفعات الأصول القديمة (مُستبدَلة بـ15 — لا يلزم تنفيذها)",
    "true",
    "'لا شيء مطلوب: 15_assets_v2 و21_banners و45 و46 هي المرجع (510 أصول مفعّلة على الأقل)'")

add("16_fix_asset_paths", "توحيد المسارات المكرّرة (نسخة آمنة — لا تلزمك الآن)",
    "true",
    qdet("select 'مسارات مكرّرة: ' || count(*) filter (where file_url ~ "
         "'^(profiles|banners|items|stickers)/(profiles|banners|items|stickers)/')::text "
         "|| ' · منها ملفه على المسار النظيف: ' || count(*) filter (where file_url ~ "
         "'^(profiles|banners|items|stickers)/(profiles|banners|items|stickers)/' and exists ("
         "select 1 from storage.objects o where o.bucket_id = 'site-assets' and o.name = "
         "regexp_replace(file_url, '^(profiles|banners|items|stickers)/(\\1)/', '\\1/')))::text "
         "|| ' (المكرّر مقصود: هكذا رُفعت الملفات)' from public.site_assets",
         "لا شيء مطلوب"))

add("28_chat_cleanup", "حالة الشات (28 ملف تنظيف أقسامه اختيارية)",
    "true",
    qdet("select 'الظاهرة: ' || count(*) filter (where status <> 'deleted')::text "
      "|| ' · المحذوفة: ' || count(*) filter (where status = 'deleted')::text "
      "|| ' · المخفية: ' || count(*) filter (where status = 'hidden')::text "
         "from public.chat_messages"))

add("34_push_notifications", "الإشعارات الفورية: 3 جداول + 18 دالة + زنادان + إعدادات المستخدم + إشعارات بصور + عرض اشتراك",
    q_ok("select ((select count(*) from information_schema.tables where table_schema = 'public' "
         "and table_name in ('push_devices', 'push_prefs', 'push_queue')) = 3 "
         "and (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname in ('push_prefs_for', 'push_allowed', "
         "'push_local_now', 'push_schedule_at', 'push_enqueue', 'push_broadcast', "
         "'push_reengage_scan', 'push_cleanup', 'push_offer_scan', 'push_targets', "
         "'push_heartbeat', "
         "'push_register_device', 'push_unregister_device', 'my_push_prefs', "
         "'push_set_prefs', 'push_test_me', 'push_on_notification', 'push_on_content')) = 18 "
         "and (select count(*) from pg_trigger where not tgisinternal and tgname in "
         "('trg_push_on_notification', 'trg_push_on_content')) = 2 "
         "and (select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'push_prefs' and column_name in ('master', 'chat', 'content', "
         "'social', 'account', 'reminders', 'quiet_enabled', 'quiet_from', 'quiet_to', "
         "'reengage_days', 'last_reengage_at', 'last_offer_at')) = 12 "
         "and (select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'push_devices' and column_name in ('token', 'user_id', 'platform', "
         "'locale', 'tz_offset', 'enabled')) = 6 "
         "and (select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'push_queue' and column_name in ('title_key', 'body_key', 'route', "
         "'collapse_key', 'priority', 'scheduled_at', 'status', 'args', 'image_url', "
         "'image_kind')) = 10)::text", "true"),
    qdet("select 'الجداول: ' || (select count(*) from information_schema.tables "
         "where table_schema = 'public' and table_name in ('push_devices', 'push_prefs', "
         "'push_queue'))::text || '/3 ' "
         "|| '· الدوال: ' || (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and (p.proname like 'push\_%' or p.proname = 'my_push_prefs'))::text "
         "|| '/18 ' || '· الزنادات: ' || (select count(*) from pg_trigger where not tgisinternal "
         "and tgname in ('trg_push_on_notification', 'trg_push_on_content'))::text || '/2 ' "
         "|| '· الأجهزة المسجّلة: ' || (select count(*) from public.push_devices)::text "
         "|| ' · في الطابور: ' || (select count(*) from public.push_queue "
         "where status = 'pending')::text "
         "|| ' · إشعارات بصور: ' || (select count(*) from public.push_queue "
         "where image_url is not null)::text "
         "|| ' · عروض اشتراك أُرسلت: ' || (select count(*) from public.push_prefs "
         "where last_offer_at is not null)::text"))

add("35_push_live", "تشغيل الإشعارات الحقيقية: جدولة كل دقيقة + فوري للمنشن + طبيب التشخيص",
    q_ok("select ((select count(*) from information_schema.tables where table_schema = 'public' "
         "and table_name = 'push_config') = 1 "
         "and (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname in ('push_dispatch_tick', 'push_daily_tick', "
         "'push_live_enable', 'push_live_disable', 'push_doctor', 'push_on_queue_urgent')) = 6 "
         "and (select count(*) from pg_trigger where not tgisinternal "
         "and tgname = 'trg_push_queue_urgent') = 1 "
         "and (select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'push_config' and column_name in "
         "('function_url', 'cron_secret', 'enabled')) = 3)::text", "true"),
    qdet("select 'الجدولة: ' || (select count(*) from pg_extension "
         "where extname in ('pg_cron', 'pg_net'))::text || '/2 إضافة' "
         "|| ' · الرابط محفوظ: ' || coalesce((select case when coalesce(btrim(function_url), '') <> '' "
         "then 'نعم' else 'لا' end from public.push_config where id = 1), 'لا') "
         "|| ' · الأجهزة: ' || (select count(*) from public.push_devices where enabled)::text "
         "|| ' · مُرسل 24 ساعة: ' || (select count(*) from public.push_queue "
         "where status = 'sent' and sent_at > now() - interval '24 hours')::text"))

add("36_profile_stats", "إحصاءات الملف الشخصي للجميع: أصدقاء · تنزيلات · مفضلة · مستوى · سلسلة",
    q_ok("select ((select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'profile_stats') = 1 "
         "and (select count(*) from information_schema.parameters where specific_name in "
         "(select specific_name from information_schema.routines where routine_schema = 'public' "
         "and routine_name = 'profile_stats') and parameter_name in ('friends', 'downloads', "
         "'favorites', 'level', 'xp_in_level', 'xp_to_next', 'streak', 'daily_claimed', "
         "'daily_reward')) = 9 "
         "and (select prosecdef from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'profile_stats' limit 1))::text", "true"),
    qdet("select 'الدالة: ' || (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'profile_stats')::text || '/1 ' "
         "|| '· security definer: ' || coalesce((select case when prosecdef then 'نعم' else 'لا' end "
         "from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' "
         "and p.proname = 'profile_stats' limit 1), 'لا')"))

add("37_profile_reports", "الإبلاغ عن عضو: عمود الهدف + دالة محمية + فهرس",
    q_ok("select ((select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'chat_reports' and column_name = 'target_user_id') = 1 "
         "and (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'chat_report_user') = 1 "
         "and (select count(*) from pg_indexes where schemaname = 'public' "
         "and indexname = 'chat_reports_target_idx') = 1)::text", "true"),
    qdet("select 'العمود: ' || (select count(*) from information_schema.columns "
         "where table_schema = 'public' and table_name = 'chat_reports' "
         "and column_name = 'target_user_id')::text || '/1 ' "
         "|| '· الدالة: ' || (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname = 'chat_report_user')::text || '/1'"))

add("38_user_mute · 39_notif_revert", "كتم عضو بزر واحد والإشعارات كما كانت بلا إسقاط",
    q_ok("select ((select count(*) from information_schema.tables where table_schema = 'public' "
         "and table_name = 'user_mutes') = 1 "
         "and (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname in ('can_mute_members', 'user_mute', "
         "'user_unmute', 'my_muted_users', 'i_muted_user')) = 5 "
         "and (select count(*) from pg_trigger where not tgisinternal "
         "and tgname = 'trg_push_drop_muted_actor') = 0 "
         "and (select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'push_prefs' and column_name = 'muted_users') = 0 "
         "and (select count(*) from pg_policies where schemaname = 'public' "
         "and tablename = 'user_mutes' and policyname = 'user_mutes_read') = 1)::text", "true"),
    qdet("select 'الجدول: ' || (select count(*) from information_schema.tables "
         "where table_schema = 'public' and table_name = 'user_mutes')::text || '/1 ' "
         "|| '· الدوال: ' || (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname in ('can_mute_members', 'user_mute', "
         "'user_unmute', 'my_muted_users', 'i_muted_user'))::text || '/5 ' "
         "|| '· المكتومون: ' || (select count(*) from public.user_mutes)::text"))

# ═══════════════════════════════════════════════════════════════════════════
#  41_console_link_codes.sql — secure PlayStation device linking
# ═══════════════════════════════════════════════════════════════════════════
CONSOLE_TABLES = ["linked_consoles", "console_link_codes", "console_link_audit"]
add("41_console_link_codes", "Secure console-link tables exist (3/3)",
    q_ok("select (count(*) = 3)::text from information_schema.tables "
         "where table_schema = 'public' and table_name in "
         "('linked_consoles', 'console_link_codes', 'console_link_audit')", "true"),
    qdet("select count(*)::text || '/3' from information_schema.tables "
         "where table_schema = 'public' and table_name in "
         "('linked_consoles', 'console_link_codes', 'console_link_audit')"))

CONSOLE_FUNCTIONS = [
    "console_private_normalize_code", "console_private_random_code",
    "console_code_create", "console_code_lookup", "console_code_approve",
    "console_code_consume", "console_code_complete", "console_list",
    "console_unlink", "console_unlink_all", "console_session_touch",
    "console_link_cleanup",
]
add("41_console_link_codes", "Secure console-link RPCs exist (12/12)",
    q_ok("select (count(distinct p.proname) = 12)::text from pg_proc p "
         "join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname in (" +
         ", ".join("'%s'" % name for name in CONSOLE_FUNCTIONS) + ")", "true"),
    qdet("select count(distinct p.proname)::text || '/12' from pg_proc p "
         "join pg_namespace n on n.oid = p.pronamespace "
         "where n.nspname = 'public' and p.proname in (" +
         ", ".join("'%s'" % name for name in CONSOLE_FUNCTIONS) + ")"))

add("41_console_link_codes", "Codes store only a poll-secret hash, never session tokens",
    q_ok("select (((select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'console_link_codes' and column_name = 'poll_secret_hash') = 1 "
         "and (select count(*) from information_schema.columns where table_schema = 'public' "
         "and table_name = 'console_link_codes' and (column_name = concat('access', '_token') "
         "or column_name = concat('refresh', '_token'))) = 0))::text", "true"),
    qdet("select string_agg(column_name, ' · ' order by column_name) from information_schema.columns "
         "where table_schema = 'public' and table_name = 'console_link_codes' "
         "and (column_name = 'poll_secret_hash' or column_name = concat('access', '_token') "
         "or column_name = concat('refresh', '_token'))"))

add("41_console_link_codes", "Owner-only linked-console RLS policy exists",
    q_ok("select (count(*) = 1)::text from pg_policies where schemaname = 'public' "
         "and tablename = concat('linked', '_consoles') "
         "and policyname = 'linked_consoles_select_own'", "true"),
    qdet("select count(*)::text || '/1' from pg_policies where schemaname = 'public' "
         "and tablename = concat('linked', '_consoles') "
         "and policyname = 'linked_consoles_select_own'"))

# ═══════════════════════════════════════════════════════════════════════════
#  42–45 focused production fixes
# ═══════════════════════════════════════════════════════════════════════════
add("42_visible_profiles_access", "visible_profiles readable while raw profiles stays private",
    q_ok("select (has_table_privilege('anon', 'public.visible_profiles', 'select') "
         "and has_table_privilege('authenticated', 'public.visible_profiles', 'select') "
         "and not has_table_privilege('anon', 'public.profiles', 'select') "
         "and not has_table_privilege('authenticated', 'public.profiles', 'select'))::text", "true"),
    qdet("select 'visible anon/auth: ' || "
         "has_table_privilege('anon', 'public.visible_profiles', 'select')::text || '/' || "
         "has_table_privilege('authenticated', 'public.visible_profiles', 'select')::text || "
         "' · raw profiles anon/auth: ' || "
         "has_table_privilege('anon', 'public.profiles', 'select')::text || '/' || "
         "has_table_privilege('authenticated', 'public.profiles', 'select')::text"))

add("43_content_download_integrity", "downloads require an existing Storage object before recording",
    q_ok("select ((position('storage.objects' in pg_get_functiondef("
         "'public.record_content_download(uuid)'::regprocedure)) > 0) "
         "and (select count(*) from pg_trigger where not tgisinternal "
         "and tgname = 'content_items_require_uploaded_file') = 1 "
         "and to_regprocedure('public.ensure_published_content_file()') is not null)::text", "true"),
    qdet("select 'record guard: ' || (position('storage.objects' in pg_get_functiondef("
         "'public.record_content_download(uuid)'::regprocedure)) > 0)::text || "
         "' · publish trigger: ' || (select count(*) from pg_trigger "
         "where not tgisinternal and tgname = 'content_items_require_uploaded_file')::text"))

add("44_fix_profile_asset_guard", "trusted profile RPCs pass the strict protected-column trigger",
    q_ok("select ((position('app.allow_profile_write' in pg_get_functiondef("
         "'public.guard_profile_update()'::regprocedure)) > 0) "
         "and (position('app.allow_profile_write' in pg_get_functiondef("
         "'public.set_profile_asset(text,text)'::regprocedure)) > 0) "
         "and (position('app.allow_profile_write' in pg_get_functiondef("
         "'public.update_my_profile(text,text,text,boolean,text)'::regprocedure)) > 0))::text", "true"),
    qdet("select 'guard/RPCs: ' || "
         "(position('app.allow_profile_write' in pg_get_functiondef("
         "'public.guard_profile_update()'::regprocedure)) > 0)::text || '/' || "
         "(position('app.allow_profile_write' in pg_get_functiondef("
         "'public.set_profile_asset(text,text)'::regprocedure)) > 0)::text || '/' || "
         "(position('app.allow_profile_write' in pg_get_functiondef("
         "'public.update_my_profile(text,text,text,boolean,text)'::regprocedure)) > 0)::text"))

# ═══════════════════════════════════════════════════════════════════════════
#  كتابة الملف
# ═══════════════════════════════════════════════════════════════════════════
HEAD = r'''-- ============================================================================
--  AddonStation Mobile — ٩٩) فاحص القاعدة: «هل نُفِّذ كل SQL كما نريد؟»
-- ============================================================================
--
--  ماذا يفعل؟ يفحص **كل ملف SQL سلّمناه لك** (01 → 46) بنداً بنداً، ويطبع
--  جدولاً واحداً: كل صف = بند · العمود «الحالة» ✅ أو ❌ · والعمود «التفاصيل»
--  يقول لك ما هو الناقص بالاسم بالضبط.
--
--  كيف أستعمله؟
--      Supabase → SQL Editor → الصق **الملف كاملاً** → RUN.
--      اقرأ الجدول: كل ما عليه ❌ = بقية من ملف SQL لم يُنفَّذ (أو نُفِّذ ناقصاً).
--      آخر صف هو المجموع.
--
--  هل يغيّر شيئاً؟ **لا** — الملف للقراءة فقط (SELECT)، لا يحذف ولا يعدّل.
--  الشيء الوحيد الذي يُنشئه: دالة تشخيص صغيرة public.diag_text (لأن فحص
--  جدول غير موجود يجب أن يُظهر ❌ لا أن تُفشل الفحص كله).
--  لحذفها بعد الاطمئنان:  drop function if exists public.diag_text(text);
--
--  آمن للتكرار: نفّذه متى شككت، أو بعد تنفيذ أي ملف SQL جديد.
--
--  ⚠️ ترتيب مهم — بعض الملفات تُعيد بناء الجدول:
--     • `15_assets_v2.sql` يبدأ بـ `delete from public.site_assets` ثم يزرع
--       الدفعة، و`21_banners.sql` يضيف 40 بانراً ⇒ **نفّذ 15 قبل 21** دائماً؛
--       وإلا مُحيت البانرات.
--     • الترتيب الموصى به للبقية: 26 (التسلسل) · 27 (أصول الإدارة) · 31 ثم
--       45 (صورة onefree الوحيدة) · 46 (الحزمتان المدفوعتان) في النهاية.
--       ارفع ملفات profile-packs إلى Storage قبل 46؛ وكل هذه الملفات آمنة للتكرار.
--     • النتيجة المرجعية: 510 أصول مفعّلة على الأقل (101 أفاتار)؛ وقد تظهر
--       إضافات الإدارة فوق هذا الحد. إن نقصت البانرات فأعِد تنفيذ 21 وحده.
-- ============================================================================

create or replace function public.diag_text(q text) returns text
language plpgsql stable
as $fn$
declare
  v text;
begin
  -- نُغلّف الاستعلام كقيمة واحدة ثم نحوّلها نصّاً: فيعمل مع أي نوع (عدّاد ·
  -- منطقي · نصّ) بلا خطأ عدم تطابق الأنواع.
  execute 'select (' || q || ')::text' into v;
  return v;
exception when others then
  return null;        -- جدول/عمود مفقود ⇒ null ⇒ تُقرأ ❌ مع «مفقود»
end;
$fn$;

comment on function public.diag_text(text) is
  'دالة تشخيص لملف 99_VERIFY_ALL.sql: تُنفّذ استعلاماً وترجع نصّه، أو null إن فشل.';

-- للاطمئنان: لا تُتاح للزوار ولا للمسجّلين (تبقى لك في SQL Editor).
do $revoke$
begin
  begin
    revoke all on function public.diag_text(text) from anon, authenticated;
  exception when undefined_object then null;   -- لو لم يوجد الدور
  end;
end;
$revoke$;

with checks(n, file_, item, ok, detail) as (
'''

TAIL = r'''
)
select n                                  as "#",
       file_                              as "الملف / الخطوة",
       item                               as "البند",
       case when ok then '✅' else '❌' end as "الحالة",
       coalesce(detail, '—')              as "التفاصيل"
  from checks
union all
select 999999,
       '—',
       'المجموع',
       case when count(*) filter (where ok is not true) = 0
            then '✅ كله تمام'
            else '❌ ناقص ' || (count(*) filter (where ok is not true))::text end,
       count(*)::text || ' بنداً فُحص · ' || (count(*) filter (where ok))::text || ' سليم'
         || coalesce(' · راجع بنداً في هذه الملفات: ' || (select string_agg(distinct f, ' · ')
                                             from unnest(array(select file_ from checks
                                                                where ok is not true)) f), '')
  from checks
 order by 1;

-- ---------------------------------------------------------------------------
--  ماذا بعد؟
--   • كل الصفوف ✅ ⇒ القاعدة مطابقة تماماً لكل ملفات SQL (01 → 41).
--   • الصف الأخير (المجموع) يسرد أسماء الملفات التي فيها بند ❌ — لا يعني أن
--     الملفات نفسها ناقصة، بل أن بنداً واحداً فيها لم يتحقّق: راجع عموده.
--   • ظهر ❌ في ملف معيّن ⇒ نفّذ ذلك الملف من `supabase/` في SQL Editor
--     (كله مرة واحدة)، ثم أعد تشغيل هذا الفاحص.
--   • ملف 15_assets_v2.sql يعطّل الأفاتارات المجانية القديمة بنفسه، و31
--     يثبّت onefree — فإن نفّذت 15 بعد 31، أعد تنفيذ 31 ليُفعَّل onefree وحده.
--   • لا تنسَ رفع ملفات الصور إلى المخزن: الفحص الأخير يتأكد من وجود
--     site-assets/profiles/onefree.png فعلاً.
--   • نقص البانرات أو «532 ← 492»؟ معناه أن 15 نُفِّذ بعد 21 ⇒ أعِد تنفيذ 21.
-- ---------------------------------------------------------------------------
'''

lines = [HEAD]
for n, f, item, ok, detail in CHECKS:
    if isinstance(ok, dict):
        ok_sql = ok["raw"]
    else:
        ok_sql = ok
    lines.append(f"  select {n}, '{f}', '{item}',\n         {ok_sql},\n         {detail}")
    if n != CHECKS[-1][0]:
        lines.append("  union all")
lines.append(TAIL)

sql = "\n".join(lines).replace("'", "''").replace("''''", "''")  # safety no-op
# نُعيد التصحيح: لا نريد مضاعفة الفواصل العليا (لم نضف أي شيء)
sql = "\n".join(lines)

io.open(ROOT + "/supabase/99_VERIFY_ALL.sql", "w", encoding="utf-8").write(sql)
print(f"✔ كُتب supabase/99_VERIFY_ALL.sql — {len(CHECKS)} بنداً · "
      f"{len(sql.splitlines())} سطراً · {len(sql.encode()) / 1024:.0f} KB")
