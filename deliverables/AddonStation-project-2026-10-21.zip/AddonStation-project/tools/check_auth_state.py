#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
حارس حالة الدخول — يمنع عودة السلوك الذي شكا منه المالك:

  «لما أسجّل، لازم التطبيق بالكامل يعرف أني سجّلت دخول أو أنشأت حساب،
   لأنه لما أضغط على الإعدادات أو ملف شخصي تظهر لي صفحة التسجيل مرة أخرى.»

الأسباب التي عولجت (ولا يجوز أن تعود):

  1) **تبويب الملف بلا شاشة ضيف**: المستخدم غير المسجّل ينتقل مباشرةً إلى
     شاشة الدخول؛ زرّ الرجوع يعيده للرئيسية ولا يكرّر التحويل.

  2) **إنشاء حساب بتأكيد بريد**: `supabase/signup` لا يُرجع جلسة حين يكون
     «Confirm email» مفعّلاً. المعتمد: بطاقة تأكيد + إعادة إرسال، ثم Login؛
     لا تسجيل دخول تلقائي ولا معاملة رابط signup كرابط recovery.

  3) **خروج تلقائي غير مرغوب**: رفض توكن التحديث لا يمسح الجلسة محلياً؛
     لا يُسجَّل خروج صاحب الحساب إلا عند ضغطه على زر الخروج.

  4) **قراءة مشفّرة تُسقط الجلسة عند الفشل**: فشل فكّ تشفير المخزن (Keystore)
     يُعالَج بلا انهيار، ولا يحذف بيانات الجلسة تلقائياً.

  5) **الشاشات التي تعتمد على الحساب** يجب أن تُحدّث نفسها عند تغيّر حالة
     الدخول (`signedIn` ضمن مفاتيح التحميل)، وإلا عرضت بيانات ضيف بعد الدخول.

الاستخدام:
    python3 tools/check_auth_state.py        # 0 = سليم · 1 = عاد أحد الأسباب
"""
import io
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "android", "app", "src", "main", "java", "com", "addonstation", "mobile")
RES = os.path.join(ROOT, "android", "app", "src", "main", "res")

problems: list[str] = []


def read(rel: str) -> str:
    path = os.path.join(SRC, rel)
    if not os.path.exists(path):
        problems.append(f"ملف مفقود: {rel}")
        return ""
    return io.open(path, encoding="utf-8").read()


# 1) لا صفحة ضيف للملف؛ والإعدادات لا تفرض الدخول على المستخدم
for rel in ("ui/profile/ProfileScreens.kt", "ui/settings/SettingsScreen.kt"):
    text = read(rel)
    code = re.sub(r"(?m)^\s*(//|\*|/\*).*$", "", text)   # بلا تعليقات
    if rel.endswith("SettingsScreen.kt") and re.search(
        r"LaunchedEffect\([^)]*signedIn[^)]*\)\s*\{\s*onLogin\(\)", code
    ):
        problems.append(f"{rel}: عاد الطرد القسري إلى شاشة الدخول")
    if rel.endswith("ProfileScreens.kt") and "GuestProfileScreen" in text:
        problems.append("ui/profile/ProfileScreens.kt: شاشة الزائر ما زالت موجودة")

# 1ب) بعد تسجيل الخروج: لا شاشة دخول مفروضة
prof = read("ui/profile/ProfileScreens.kt")
code_prof = re.sub(r"(?m)^\s*(//|\*|/\*).*$", "", prof)
signout = re.search(r"container\.auth\.signOut\(\)[\s\S]{0,400}?\}\s*\)?", code_prof)
if signout and "onLogin()" in signout.group(0):
    problems.append("ui/profile/ProfileScreens.kt: الخروج يُظهر شاشة الدخول قسراً (العودة للرئيسية كضيف)")

# 1ج) توكن الجهاز يُلغى عند الخروج (وإلا وصلت إشعارات الحساب السابق لجهاز آخر)
nav = read("ui/nav/AppNav.kt")
if "PushRegistrar.onSessionChanged" not in nav and "onSessionChanged(ctx, false)" not in nav:
    problems.append("ui/nav/AppNav.kt: لا إلغاء لتوكن الجهاز عند الخروج (onSessionChanged)")
profile_start = nav.find("composable(Routes.PROFILE)")
profile_end = nav.find("// المصادقة", profile_start)
profile_route = nav[profile_start:profile_end] if profile_start >= 0 and profile_end > profile_start else ""
tab_start = nav.find("fun goTab(target: MainTab)")
tab_end = nav.find("fun selectTab", tab_start)
tab_router = nav[tab_start:tab_end] if tab_start >= 0 and tab_end > tab_start else ""
select_start = nav.find("fun selectTab(target: MainTab)")
select_end = nav.find("/**", select_start)
select_router = nav[select_start:select_end] if select_start >= 0 and select_end > select_start else ""
if "tab == target && !(target == MainTab.Profile && !signedIn)" not in select_router:
    problems.append("ui/nav/AppNav.kt: نقر تبويب الملف المحدد لا يفتح الدخول عند تسجيل الخروج")
if not all(token in tab_router for token in (
    "target == MainTab.Profile && !signedIn",
    "navController.navigate(Routes.LOGIN)",
    "popUpTo(Routes.HOME) { inclusive = false }",
    "launchSingleTop = true",
)):
    problems.append("ui/nav/AppNav.kt: تبويب الملف لا يفتح الدخول مباشرةً مع رجوع آمن للرئيسية")
if "onLogin =" in profile_route or "onOpenSignup =" in profile_route:
    problems.append("ui/nav/AppNav.kt: صفحة الملف ما زالت تعتمد على شاشة الزائر")

# 2) إنشاء حساب: معالجة تأكيد البريد ثم Login، بلا دخول تلقائي
screens = read("ui/auth/AuthScreens.kt")
login_start = screens.find("fun LoginScreen(")
signup_start = screens.find("fun SignUpScreen(")
confirm_screen_start = screens.find("private fun EmailConfirmationScreen(")
login = screens[login_start:signup_start] if login_start >= 0 and signup_start > login_start else ""
signup = screens[signup_start:confirm_screen_start] if signup_start >= 0 and confirm_screen_start > signup_start else ""
if "pendingConfirm" not in signup:
    problems.append("ui/auth/AuthScreens.kt: لا معالجة لحالة «الحساب أُنشئ وينتظر تأكيد البريد»")
for key in ("auth_confirm_retry", "auth_confirm_resend", "auth_confirm_hint"):
    if key not in screens:
        problems.append(f"ui/auth/AuthScreens.kt: عنصر {key} مفقود من بطاقة التأكيد")
if "container.auth.signIn(" in signup or "container.state.refreshAll()" in signup:
    problems.append("ui/auth/AuthScreens.kt: عاد تسجيل الدخول التلقائي من شاشة إنشاء الحساب")
if not all(token in signup for token in (
    "clearEmailConfirmationSession()", "container.state.setSignedIn(false)", "onOpenLogin()",
)):
    problems.append("ui/auth/AuthScreens.kt: تأكيد/إنشاء الحساب لا ينتهي في Login بجلسة نظيفة")
if not all(token in login for token in ("container.state.setSignedIn(true)", "onSuccess()")):
    problems.append("ui/auth/AuthScreens.kt: نجاح الدخول لا يبلّغ الحالة/التنقّل")
if "container.state.refreshAll()" in login:
    problems.append("ui/auth/AuthScreens.kt: الانتقال بعد الدخول ما زال ينتظر تحميل الشبكة")

repo = read("data/repo/AuthRepository.kt")
if "fun resendConfirmation" not in repo:
    problems.append("data/repo/AuthRepository.kt: دالة resendConfirmation مفقودة")
if "fun clearEmailConfirmationSession" not in repo or "acceptEmailLink" not in repo:
    problems.append("data/repo/AuthRepository.kt: فصل جلسة تأكيد البريد/نوع الرابط مفقود")

client = read("data/SupabaseClient.kt")
if '"resend"' not in client:
    problems.append("data/SupabaseClient.kt: نقطة إعادة إرسال رابط التأكيد (resend) مفقودة")
if not all(token in client for token in (
    "AuthEmailLinkKind", "RECOVERY", "SIGNUP_CONFIRMATION", "acceptEmailLink",
    '"signup", "email", "email_confirmation"', "authPathWithRedirect(\"signup\"",
)):
    problems.append("data/SupabaseClient.kt: لا يوجد فصل كامل بين رابط signup ورابط recovery")
if not all(token in nav for token in (
    "AuthEmailLinkKind.RECOVERY", "Routes.RESET",
    "AuthEmailLinkKind.SIGNUP_CONFIRMATION", "Routes.LOGIN",
)):
    problems.append("ui/nav/AppNav.kt: وجهتا رابط الاستعادة وتأكيد التسجيل غير منفصلتين")
finish_start = nav.find("fun finishLogin()")
finish_end = nav.find("\n    val density", finish_start)
finish_login = nav[finish_start:finish_end] if finish_start >= 0 and finish_end > finish_start else ""
if not all(token in finish_login for token in (
    "navController.navigate(Routes.HOME)",
    "popUpTo(Routes.HOME) { inclusive = true }",
    "container.state.refreshAll()",
    "container.assets.all()",
)):
    problems.append("ui/nav/AppNav.kt: نجاح Login لا يمسح مسار المصادقة إلى Home ويحدّث البيانات بالخلفية")

# 3) لا خروج تلقائياً: المسح محصور بدالة الخروج الصريح
refresh_start = client.find("suspend fun refreshSession()")
logout_start = client.find("suspend fun signOut()", refresh_start)
refresh_body = client[refresh_start:logout_start] if refresh_start >= 0 and logout_start > refresh_start else ""
logout_body = client[logout_start:client.find("suspend fun sendRecovery", logout_start)] if logout_start >= 0 else ""
if "sessionStore.clear()" in refresh_body:
    problems.append("data/SupabaseClient.kt: رفض التوكن يمسح الجلسة تلقائياً")
if "sessionStore.clear()" not in logout_body:
    problems.append("data/SupabaseClient.kt: الخروج الصريح لا يمسح الجلسة")

# 4) قراءة المخزن المشفّر آمنة وغير هدّامة
store = read("data/SessionStore.kt")
idx = store.find("private fun readFromDisk()")
end = store.find("\n    fun clear()", idx) if idx >= 0 else -1
tail = store[idx:end] if idx >= 0 and end > idx else ""
if idx < 0 or "catch" not in tail:
    problems.append("data/SessionStore.kt: قراءة المخزن بلا حماية من فشل فكّ التشفير")
if "prefs.edit().clear()" in tail:
    problems.append("data/SessionStore.kt: فشل فكّ التشفير يحذف بيانات الجلسة تلقائياً")

# 5) تغيير اللغة لا يعيد إنشاء النشاط ولا يلمس جلسة الحساب
settings = read("ui/settings/SettingsScreen.kt")
main_activity = read("MainActivity.kt")
if "applyAppLocale(language.code)" not in settings:
    problems.append("ui/settings/SettingsScreen.kt: تغيير اللغة لا يحدّث Compose مباشرة")
if "recreate()" in settings:
    problems.append("ui/settings/SettingsScreen.kt: تغيير اللغة ما زال يعيد إنشاء النشاط")
if "LocalConfiguration provides localizedConfiguration" not in main_activity:
    problems.append("MainActivity.kt: سياق موارد اللغة غير متاح فوراً لـCompose")

# 6) الشاشات المرتبطة بالحساب تُحدّث نفسها عند تغيّر حالة الدخول
for rel, needle in (
    ("ui/store/StoreScreens.kt", "reloadTick, signedIn"),
    ("ui/account/AccountScreens.kt", "reloadTick, signedIn"),
):
    code = re.sub(r"(?m)^\s*(//|\*|/\*).*$", "", read(rel))
    if needle not in code:
        problems.append(f"{rel}: التحميل لا يعتمد على حالة الدخول ({needle})")

# 6) النصوص موجودة في اللغات الثماني
KEYS = (
    "auth_confirm_title", "auth_confirm_text", "auth_confirm_retry",
    "auth_confirm_resend", "auth_confirm_resent", "auth_confirm_hint",
    "common_guest",
)
user_labels = {
    "values": "User",
    "values-ar": "مستخدم",
    "values-pt": "Utilizador",
    "values-es": "Usuario",
    "values-ru": "Пользователь",
    "values-zh": "用户",
    "values-fr": "Utilisateur",
    "values-tr": "Kullanıcı",
}
for locale in ("values", "values-ar", "values-pt", "values-es", "values-ru", "values-zh", "values-fr", "values-tr"):
    path = os.path.join(RES, locale, "strings.xml")
    text = io.open(path, encoding="utf-8").read() if os.path.exists(path) else ""
    missing = [k for k in KEYS if f'name="{k}"' not in text]
    if missing:
        problems.append(f"{locale}: نصوص ناقصة → {', '.join(missing)}")
    expected = user_labels[locale]
    if f'<string name="common_guest">{expected}</string>' not in text:
        problems.append(f"{locale}: تسمية المستخدم غير المسجّل لا تستخدم User/مستخدم")

print("حارس حالة الدخول")
print("-" * 52)
print("فُحص: الملف الشخصي · الإعدادات · الإنشاء · الدخول · الجلسة · تبديل اللغة · المتجر · ٨ لغات")
print()
if problems:
    for p in problems:
        print("✗", p)
    print(f"\n✗ عاد {len(problems)} سبباً من أسباب «التطبيق لا يعرف أني سجّلت».")
    sys.exit(1)
print("🟢 تبويب الملف يفتح الدخول مباشرةً لغير المسجّل · زرّ الرجوع للرئيسية · تغيير اللغة بلا إعادة إنشاء ·")
print("   لا خروج تلقائياً عند تعذّر التجديد · مسح الجلسة محصور بالخروج الصريح ·")
print("   Login ينتقل فوراً إلى Home ويحدّث بالخلفية · تأكيد التسجيل يفتح Login لا Reset ·")
print("   النصوص الثمانية مكتملة.")
