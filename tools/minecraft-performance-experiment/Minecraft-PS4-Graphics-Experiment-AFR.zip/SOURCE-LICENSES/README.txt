AFR plugin attribution and source
=================================
AFR (Application File Redirector), by SiSTR0 and jocover, is from the
GoldHEN Plugins Repository. It is provided under GPL-3.0; the unmodified
repository source and LICENSE are included as a ZIP next to this notice.

Official release: https://github.com/GoldHEN/GoldHEN_Plugins_Repository/releases/tag/1.188
Release source: https://github.com/GoldHEN/GoldHEN_Plugins_Repository/tree/caacf01174654235459d48ab9d0b9e00a588b300
The release page publishes this SHA-256 for plugins/afr.prx:
9bf82dd027b4b3a7e5f22337be8aa9d70f1753a2a17f3af52fea8ff1b8cd3fca
The supplied binary has that exact digest. It was obtained from a public
third-party mirror and checked against the official release page, because the
release asset itself was not accessible from the build environment:
https://github.com/Silane-la-banane/DRIVECLUB/blob/main/GoldPlugins-1.188-caacf011/plugins/afr.prx

A GoldHEN Plugins SDK source snapshot is also included (MIT license in its ZIP).
The snapshot is the last SDK commit published before the 1.188 release;
its exact use in that release was not independently established. Build
instructions are in the upstream source. The OpenOrbis toolchain is separate:
https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain

This is an experimental personal configuration overlay. It is not an official
GoldHEN or Mojang release and was not tested on a PS4.
